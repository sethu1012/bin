/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable @typescript-eslint/no-unused-vars */
import { zodResolver } from "@hookform/resolvers/zod";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import SelectBox from "~/components/form/select-box";
import { SubmitButton as Button } from "~/components/form/submit-button";
import TextAreaField from "~/components/form/SEFL/text-area";
import TextBoxField from "~/components/form/text-box.tsx";
import { useAgent } from "~/hooks/SEFL/use-agent";
import { recognizeTextInImage } from "~/utils/basic";
import { SELECTED_FIELD } from "~/utils/constants";
import { cn } from "~/utils/tailwind";
import DocumentListModal from "../modals/document-modal.tsx";
import ExceptionModal from "../modals/exception-modal.tsx";
import HelpModal from "../modals/help-modal.tsx";
import SubmitModal from "../modals/submit-modal.tsx";
import HeaderFields from "./headers.tsx";
import Sidebar from "./side-bar.tsx";
import AgentTables from "./tables.tsx";
import Timer from "./timer.tsx";
import Popover from "./unified-viewer/generic-file-viewer.tsx";

import { Bounce, toast } from "react-toastify";
import { useTimer } from "~/hooks/use-timer";
import ResponseModal from "../modals/response-modal.tsx";
import SMEHoldModal from "../modals/SMEHoldModal.tsx";
import { useLocation, useNavigate } from "@tanstack/react-router";
import SearchModal from "../modals/search-modal.tsx";
import {
  agentSaveAndConfirm,
  getAgentTaskDetailsById,
  getCommodityDescription,
  putAgentTaskDetails,
} from "~/services/SEFL/agent.services.ts";
import {
  getBillToMasterFields,
  getSHCCustomerCode,
} from "~/services/SEFL/agent.services";
import ZipSearchModal from "../modals/zip-search-modal.tsx";
import { AgentTableRef } from "./table";
import PromptsComponent from "./prompts.tsx";

type TTabs = "headers" | "tables";

interface BillToRecord {
  account_code: string;
  name: string;
  addr_1: string;
  addr_2: string;
  addr_3: string;
  city: string;
  state: string;
  zip: string;
  shc?: string;
  master_data?: any;
}
interface BillToMasterApiResponse {
  data: BillToRecord[];
  message: string;
  status: number;
}

const AgentForm = () => {
  const [activeTab, setActiveTab] = useState<TTabs>("headers");
  const [activeSection, setActiveSection] = useState<number>(0);
  //const agentTableRef = useRef<AgentTableRef | null>(null);
  // Store refs by table id
  const agentTableRefs = useRef<Record<string, AgentTableRef | null>>({});

  const {
    data,
    formSchema,
    values,
    documents,
    readOnly,
    extractionVersion,
    setValues,
    formStatus,
    allSchemas,
    partialSchemas,
    setFormFields,
    allFormFields,
    allTableFields,
    setTableFields,
    refreshData,
  } = useAgent();
  const taskId = Number(values?.header[0]["taskid"]);

  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [showSideBar, setShowSideBar] = useState<boolean>(false);
  const [isOpen, setIsOpen] = useState(false);
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [isFormSaved, setIsFormSaved] = useState<boolean>(false);
  const [isNextTaskEnabled, setIsNextTaskEnabled] = useState(false);
  const [document, setDocument] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isDocumentListModalOpen, setIsDocumentListModalOpen] = useState(false);
  const zoningWindowRef = useRef<Window | null>(null);
  const [selectedVersion, setSelectedVersion] = useState<string>("lastversion");
  const [, setShowDocumentModal] = useState(false);
  const [isRoleSME, setIsRoleSME] = useState<boolean>(false);
  const [respondModal, setRespondModal] = useState<boolean>(false);
  const [popupType, setPopupType] = useState<"zoning" | "regular">("zoning");
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  const [isRoleWNSSME, setIsRoleWNSSME] = useState<boolean>(false);
  const [wnsSMEHoldModal, setWnsSMEHoldModal] = useState<boolean>(false);
  const [ifBusinessRuleRole, setBusinessRuleRole] = useState<boolean>(false);
  //const [useTimeout, setUseTimeout] = useState(false);
  const popoverRef = useRef<any>(null);

  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [enableCountry, setEnableCountry] = useState({ field: "", count: 0 });

  const [zip, setZip] = useState("");
  const [stateValue, setStateValue] = useState("");
  const [name, setName] = useState("");
  const [address1, setAddress1] = useState("");
  const [city, setCity] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [zipPopupHeaderDisplay, setZipPopupHeaderDisplay] = useState("");
  const [isZipSearchModalOpen, setIsZipSearchModalOpen] = useState(false);
  const [submitTrigger, setSubmitTrigger] = useState(0);
  const [areaExpand, setAreaExpand] = useState(false);

  const [searchSource, setSearchSource] = useState("");
  const agentForm = useForm({
    resolver: (values, context, options) => {
      if (allSchemas != null) {
        const shippingCode = values.header[0].shippingcode;
        const validCodes = ["Regular", "Hazmat"] as const;

        if (validCodes.includes(shippingCode as any)) {
          setFormFields(allFormFields![shippingCode]);
          setTableFields(allTableFields![shippingCode]);
          if (!readOnly) {
            const schema = allSchemas.type[shippingCode]?.schema;

            if (schema) {
              const createResolver = zodResolver(schema);
              return createResolver(values, context, options);
            }
          }
        }
      }

      if (formSchema) {
        if (!readOnly) {
          return zodResolver(formSchema)(values, context, options);
        }
      }

      return Promise.resolve({
        values: {},
        errors: {},
      });
    },
    mode: "onChange",
  });

  const {
    handleSubmit,
    setValue,
    watch,
    trigger,
    getValues,
    control,
    reset,
    setError,
    formState: { errors },
  } = agentForm;

  type PartyType = "shipper" | "consignee" | "billto" | "thirdparty";

  function isValidParty(key: string): key is PartyType {
    return ["shipper", "consignee", "billto", "thirdparty"].includes(key);
  }

  const groupList = [
    "topLevel",
    "headerinfo",
    "shipperconsigneebilltoinfo",
    "interlineinfo",
    "tableentity1",
    "driverinfo",
    "tableentity2",
    "tableentity3",
    "hazardousinfo",
    "tableentity3totals",
  ];

  const stateUpdater =
    (
      setterFn: React.Dispatch<React.SetStateAction<boolean>>,
      value?: boolean,
    ) =>
    () => {
      setterFn((prev) => value ?? !prev);
    };

  const handleAltNavigation = (e: KeyboardEvent) => {
    if (
      !e.altKey ||
      (e.key.toLowerCase() !== "z" && e.key.toLowerCase() !== "x")
    )
      return;

    const direction = e.key.toLowerCase(); // 'z' for next, 'x' for previous
    const activeEl = window.document.activeElement as HTMLElement | null;

    if (!activeEl) return;

    const currentBlockId = activeEl.getAttribute("aria-label");
    if (!currentBlockId) return;
    if (currentBlockId === "shipperconsigneebilltoinfo") {
      e.preventDefault();
      const activeId = activeEl?.id || "";
      const sequence = [
        {
          key: "shipper",
          z: "header.0.consigneeid",
          x: "header.0.shippingcode",
        },
        { key: "consignee", z: "header.0.billtoid", x: "header.0.shipperid" },
        {
          key: "billto",
          z: "header.0.interlinescac",
          x: "header.0.consigneeid",
        },
        { key: "interline", z: "", x: "header.0.billtoid" },
      ];

      const diraction = e.key.toLowerCase() === "z" ? "z" : "x";
      const index = sequence.findIndex((item) => activeId.includes(item.key));

      if (index !== -1 && sequence[index][diraction] !== "") {
        let El: any = window.document.getElementById(
          sequence[index][diraction],
        );
        El?.focus();
        El?.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    } else if (
      currentBlockId === "interlineinfo" &&
      e.key.toLowerCase() === "x"
    ) {
      e.preventDefault();
      let El: any = window.document.getElementById("header.0.billtoid");
      El?.focus();
      El?.scrollIntoView({ behavior: "smooth", block: "center" });
    } else {
      const currentIndex = groupList.indexOf(currentBlockId);
      if (currentIndex === -1) return;

      let targetIndex = null;

      if (direction === "z" && currentIndex < groupList.length - 1) {
        targetIndex = currentIndex + 1;
      } else if (direction === "x" && currentIndex > 0) {
        targetIndex = currentIndex - 1;
      }
      if (targetIndex !== null) {
        const targetBlockId = groupList[targetIndex];

        // Get all focusable elements in the document with the target block ID
        const targetFields = Array.from(
          window.document.querySelectorAll<HTMLElement>(
            `[aria-label="${targetBlockId}"]`,
          ),
        ).filter(
          (el) =>
            el.tabIndex !== -1 ||
            el instanceof HTMLInputElement ||
            el instanceof HTMLTextAreaElement ||
            el instanceof HTMLSelectElement,
        );

        if (targetFields.length > 0) {
          e.preventDefault();
          targetFields[0].focus();
          targetFields[0].scrollIntoView({
            behavior: "smooth",
            block: "center",
          });
        }
      }
    } // end else
  };

  const invokeWhenReady = async (
    refKey: string,
    callbackName: keyof AgentTableRef,
    retries = 5,
    delay = 200,
  ) => {
    let attempt = 0;
    while (attempt < retries) {
      const ref = agentTableRefs.current[refKey];
      if (ref && typeof ref[callbackName] === "function") {
        try {
          await (ref[callbackName] as Function)();
          return;
        } catch (error) {
          console.error(`Error running ${callbackName}:`, error);
          return;
        }
      }

      // Wait a bit before retrying (ref may not yet be assigned)
      await new Promise((res) => setTimeout(res, delay));
      attempt++;
    }

    console.warn(
      ` Ref "${refKey}" or method "${callbackName}" not ready after ${retries} tries`,
    );
  };

  useEffect(() => {
    const validators = {
      account: [
        "header.0.shipperid",
        "header.0.consigneeid",
        "header.0.billtoid",
      ],
      phone: [
        "header.0.shippercontactphone",
        "header.0.consigneephone",
        "header.0.billtophone",
      ],
      zip: [
        "header.0.shipperzip",
        "header.0.consigneezip",
        "header.0.billtozip",
      ],
    };

    // Map DOM IDs → data field names
    const fieldMap: Record<string, keyof (typeof data.dbdata.header)[0]> = {
      "header.0.shipperid": "shipperid",
      "header.0.consigneeid": "consigneeid",
      "header.0.billtoid": "billtoid",
    };

    const initialData = data?.dbdata?.header?.[0] ?? {};
    const lastKnownValues = { ...initialData };

    const fetchAndUpdate = async () => {
      const shipperid = getValues("header.0.shipperid")?.trim() || "";
      const consigneeid = getValues("header.0.consigneeid")?.trim() || "";
      const paymentterm = getValues("header.0.paymentterm")?.trim() || "";

      if (!paymentterm) return;

      const term = paymentterm.toUpperCase();
      if ((term === "P" && !shipperid) || (term === "C" && !consigneeid)) {
        return; // required values not present
      }

      try {
        const fields = (await getBillToMasterFields({
          shipperid,
          consigneeid,
          paymentterm,
        })) as
          | { status: true; data: BillToMasterApiResponse }
          | { status: false; error: unknown };

        if (
          "status" in fields &&
          fields.status &&
          fields.data?.data?.length > 0
        ) {
          const billTo = fields.data.data[0];
          setValue("header.0.billtoid", billTo.account_code?.trim() || "");
          setValue("header.0.billtoname", billTo.name?.trim() || "");
          setValue("header.0.billtoaddress", billTo.addr_1?.trim() || "");
          setValue("header.0.billtoaddress2", billTo.addr_2?.trim() || "");
          setValue("header.0.billtoaddress3", billTo.addr_3?.trim() || "");
          setValue("header.0.billtocity", billTo.city?.trim() || "");
          //setValue("header.0.billtostate", billTo.state?.trim() || "");

          setValue("header.0.billtostate", billTo.state?.trim() || "", {
            shouldValidate: true,
            shouldDirty: true,
          });
          setValue("header.0.billtozip", billTo.zip?.trim() || "");
          setValue("header.0.billtocountry", "");

          setEnableCountry((prev) => ({
            field: "billtocountry",
            count: prev.count + 1,
          }));
        } else if (
          "status" in fields &&
          fields.status &&
          fields.data?.data?.length === 0
        ) {
          const billtoid = getValues("header.0.billtoid")?.trim() || "";

          if (billtoid !== "000000000") return;

          setValue("header.0.billtoid", "");
          setValue("header.0.billtoname", "");
          setValue("header.0.billtoaddress", "");
          setValue("header.0.billtoaddress2", "");
          setValue("header.0.billtoaddress3", "");
          setValue("header.0.billtocity", "");
          // setValue("header.0.billtostate", "");
          setValue("header.0.billtostate", "", {
            shouldValidate: true,
            shouldDirty: true,
          });

          setValue("header.0.billtozip", "");
          setValue("header.0.billtocountry", "");
          setEnableCountry((prev) => ({
            field: "billtocountry",
            count: prev.count + 1,
          }));
        }
      } catch (error) {
        console.error("Error fetching BillTo Master Fields:", error);
      }
    };

    const fetchAndUpdate_SHCCode = async () => {
      const shipperid = getValues("header.0.shipperid")?.trim() || "";
      const consigneeid = getValues("header.0.consigneeid")?.trim() || "";

      try {
        const fields = (await getSHCCustomerCode({
          shipperid,
          consigneeid,
          taskId,
        })) as
          | { status: true; data: BillToMasterApiResponse }
          | { status: false; error: unknown };

        if ("status" in fields && fields.status) {
          const shcData = (fields.data as any)?.data;
          if (Array.isArray(shcData) && shcData.length > 0) {
            const shcValue = shcData[0]?.shc;
            if (shcValue !== undefined && shcValue !== null) {
              const receivedData: string = String(shcValue);

              setValue("header.0.shc", receivedData?.trim() || "", {
                shouldValidate: true,
                shouldDirty: true,
              });
              //console.log("shc Customer Code fetched data:", receivedData);
            }
          }
        }
      } catch (error) {
        console.error("Error fetching BillTo Master Fields:", error);
      }
    };

    const fetchAccessorialInstructions = () =>
      invokeWhenReady("tableentity1", "handleAccessorialInstructions");

    const fetchReferenceNumberDetails = () =>
      invokeWhenReady("tableentity2", "handleReferenceNumberDetails");

    const fetchLineItems = () =>
      invokeWhenReady("tableentity3", "handleLineItems");

    const removePhonePrefix = (value: string) => {
      if (!value) return "";
      return value.trim().replace(/\D/g, "").replace(/^1+/, "");
    };

    // 1) Run on payment term change (no DOM access)
    const sub = watch((_, { name, type }) => {
      if (name === "header.0.paymentterm" && type === "change") {
        fetchAndUpdate();
      }
    });

    function validateAccount(id: any, value: any, target?: any) {
      const prevValue = target.dataset.prevValue ?? "";
      const field = fieldMap[id];
      if (value === prevValue || value === lastKnownValues[field]) return;
      // Update cached value
      lastKnownValues[field] = value;

      // Logic based on which field changed
      if (id === "header.0.shipperid" || id === "header.0.consigneeid") {
        fetchAndUpdate();
        fetchAndUpdate_SHCCode();
      }
      if (id === "header.0.shipperid") {
        fetchLineItems();
      }
      if (validators.account.includes(id)) {
        setSubmitTrigger((prev) => prev + 1);
        fetchAccessorialInstructions();
        fetchReferenceNumberDetails();
      }
      return;
    }
    function validatePhone(id: string) {
      console.log("validatePhone called for id:", id);
      const phoneNumber = getValues(id)?.trim() || "";
      if (phoneNumber) {
        const withoutPrefix = removePhonePrefix(phoneNumber);
        setValue(id, withoutPrefix, { shouldValidate: true });
      }
      return;
    }
    function validateZip(id: string) {
      const zipCode = getValues(id)?.trim() || "";
      if (zipCode) {
        setValue(id, zipCode.trim().replace(/[^a-zA-Z0-9]/g, ""), {
          shouldValidate: true,
        });
      }
      return;
    }

    // Save current value when focused
    const onFocusIn = (e: FocusEvent) => {
      const target = e.target as HTMLInputElement | null;
      if (!target || !validators.account.includes(target.id)) return;
      target.dataset.prevValue = target.value;
    };

    // Compare and trigger fetches when focus leaves
    const onFocusOut = (e: FocusEvent) => {
      const target = e.target as HTMLInputElement | null;
      if (!target) return;
      const { id, value } = target;
      // console.log("onFocusOut called for id:", validators.phone.includes(id), "with value:", value);
      if (validators.account.includes(id))
        return validateAccount(id, value, target);
      else if (validators.phone.includes(id)) return validatePhone(id);
      else if (validators.zip.includes(id)) return validateZip(id);
      else return;
    };

    // Attach listeners once
    window.document.addEventListener("focusin", onFocusIn, true);
    window.document.addEventListener("focusout", onFocusOut, true);

    return () => {
      sub.unsubscribe();
      window.document.removeEventListener("focusin", onFocusIn, true);
      window.document.removeEventListener("focusout", onFocusOut, true);
    };
  }, [watch, getValues, setValue, trigger]);

  useEffect(() => {
    const handleAlt = (e: KeyboardEvent) => {
      // Check if Alt+S is pressed
      const activeEl = window.document.activeElement as HTMLElement | null;
      if (e.altKey && e.key.toLowerCase() === "s") {
        if (!activeEl) return;

        // trigger only when shipper fields are focused
        const shipperFields = [
          "header.0.shipperid",
          "header.0.shipper",
          "header.0.shipperaddress",
          "header.0.shipperaddress2",
          "header.0.shipperaddress3",
        ];

        // Consignee fields
        const consigneeFields = [
          "header.0.consigneeid",
          "header.0.consignee",
          "header.0.consigneeaddress",
          "header.0.consigneeaddress2",
          "header.0.consigneeaddress3",
        ];

        // BillTo fields
        const billToFields = [
          "header.0.billtoid",
          "header.0.billtoname",
          "header.0.billtoaddress",
          "header.0.billtoaddress2",
          "header.0.billtoaddress3",
        ];

        //city state & zip code
        const zipCityStateFields = [
          { name: "shipper", field: "city", shouldDisplay: "Shipper" },
          {
            name: "shipper",
            field: "state",
            shouldDisplay: "Shipper",
          },
          { name: "shipper", field: "zip", shouldDisplay: "Shipper" },
          {
            name: "consignee",
            field: "city",
            shouldDisplay: "Consignee",
          },
          {
            name: "consignee",
            field: "state",
            shouldDisplay: "Consignee",
          },
          {
            name: "consignee",
            field: "zip",
            shouldDisplay: "Consignee",
          },
          {
            name: "billto",
            field: "city",
            shouldDisplay: "Third Party",
          },
          {
            name: "billto",
            field: "state",
            shouldDisplay: "Third Party",
          },
          {
            name: "billto",
            field: "zip",
            shouldDisplay: "Third Party",
          },
        ];

        const activeAdrField = zipCityStateFields.filter(
          (e) => `header.0.${e.name}${e.field}` === activeEl?.id,
        );

        if (shipperFields.includes(activeEl.id)) {
          e.preventDefault();

          const shipperState = getValues("header.0.shipperstate") || "";
          const shipperZip = getValues("header.0.shipperzip") || "";
          const shipperName = getValues("header.0.shipper") || "";
          const shipperAddress1 = getValues("header.0.shipperaddress") || "";
          const shipperCity = getValues("header.0.shippercity") || "";
          const accountNumber = getValues("header.0.shipperid") || "";

          setZip(shipperZip);
          setStateValue(shipperState);
          setCity(shipperCity);
          setName(shipperName);
          setAddress1(shipperAddress1);
          setAccountNumber(accountNumber);

          setSearchSource("shipper");

          setIsSearchModalOpen(true); // your modal state
        } else if (consigneeFields.includes(activeEl.id)) {
          e.preventDefault();

          const consigneeState = getValues("header.0.consigneestate") || "";
          const consigneeZip = getValues("header.0.consigneezip") || "";
          const consigneeName = getValues("header.0.consignee") || "";
          const consigneeAddress1 =
            getValues("header.0.consigneeaddress") || "";
          const consigneeCity = getValues("header.0.consigneecity") || "";
          const consigneeAccountNumber =
            getValues("header.0.consigneeid") || "";

          setStateValue(consigneeState);
          setZip(consigneeZip);
          setCity(consigneeCity);
          setName(consigneeName);
          setAddress1(consigneeAddress1);
          setAccountNumber(consigneeAccountNumber);

          setSearchSource("consignee");

          setIsSearchModalOpen(true); // your modal state
        } else if (billToFields.includes(activeEl.id)) {
          e.preventDefault();

          const billToState = getValues("header.0.billtostate") || "";
          const billToZip = getValues("header.0.billtozip") || "";
          const billToName = getValues("header.0.billtoname") || "";
          const billToAddress1 = getValues("header.0.billtoaddress") || "";
          const billToCity = getValues("header.0.billtocity") || "";
          const billToAccountNumber = getValues("header.0.billtoid") || "";

          setStateValue(billToState);
          setZip(billToZip);
          setCity(billToCity);
          setName(billToName);
          setAddress1(billToAddress1);
          setAccountNumber(billToAccountNumber);

          setSearchSource("thirdparty");

          setIsSearchModalOpen(true); // your modal state
        } else if (activeEl && activeAdrField.length > 0) {
          e.preventDefault();

          const blockName = activeAdrField[0].name;
          const popupHeaderDisplay = activeAdrField[0].shouldDisplay;

          setZip(getValues(`header.0.${blockName}zip` || "") ?? "");
          setStateValue(getValues(`header.0.${blockName}state` || "") ?? "");
          setCity(getValues(`header.0.${blockName}city` || "") ?? "");
          setZipPopupHeaderDisplay(`${popupHeaderDisplay}`);
          setSearchSource(blockName);

          setIsZipSearchModalOpen(true); // your update ZIP modal state
        }
      }

      if (
        e.altKey &&
        (e.key.toLowerCase() === "z" || e.key.toLowerCase() === "x")
      ) {
        e.preventDefault();
        handleAltNavigation(e);
      }
    };

    // Attach to window (works globally)
    window.addEventListener("keydown", handleAlt, true);

    return () => {
      window.removeEventListener("keydown", handleAlt, true);
    };
  }, []);

  const navigate = useNavigate();
  const location = useLocation();
  const roleid = localStorage.getItem("roleid") as string;
  const { timeInSeconds: aht } = useTimer();
  const { resetTimer } = useTimer();

  useEffect(() => {
    if (isFormSaved && !isSubmitting) {
      setIsNextTaskEnabled(true);
    } else {
      setIsNextTaskEnabled(false);
    }
  }, [isFormSaved, isSubmitting]);

  useEffect(() => {
    const roleId = localStorage.getItem("roleid");
    // if (roleId === "8") {
    //   setIsRoleSME(true);
    // } else if (roleId === "16") {
    //   setBusinessRuleRole(true);
    // } else {
    //   setIsRoleSME(false);
    // } repeterd code removed

    setIsRoleSME(roleId === "8");
    setBusinessRuleRole(roleId === "16");
    setIsRoleWNSSME(roleId === "15");

    return () => {
      // localStorage.setItem("a", "b"); // not in use currently
      // window.dispatchEvent(new Event("storage")); // not in use currently
      if (zoningWindowRef.current) {
        zoningWindowRef.current.close();
        zoningWindowRef.current = null;
      }

      if (popoverRef.current?.closeWindow) {
        popoverRef.current.closeWindow();
      }
    };
  }, []);

  // useEffect(() => {
  //   const roleId = localStorage.getItem("roleid");
  //   // console.log(roleId);
  //   if (roleId === "15") {
  //     setIsRoleWNSSME(true);
  //   } else {
  //     setIsRoleWNSSME(false);
  //   }
  // }, []);

  const sendAht = async () => {
    stateUpdater(setIsLoading, true)();

    const response = await agentSaveAndConfirm(taskId, roleid, {
      dbdata: {
        aht,
      },
    });

    if (response.status) {
      setIsLoading(false);
      console.log(isSubmitted);
      setIsSubmitted(true);
      toast.success("Task Submitted Successfully.", {
        theme: "colored",
      });
      if (roleid === "8") {
        setTimeout(() => {
          const previousPath = sessionStorage.getItem("prevPath");

          if (previousPath) {
            navigate({ to: previousPath });
          } else {
            navigate({ to: location.pathname });
          }
        }, 1000);
      } else {
        setTimeout(async () => {
          // Fetch new task data
          await refreshData();

          // Reset the form with the new data
          reset();

          // Update UI state
          setIsSubmitted(false);
          setActiveTab("headers");

          resetTimer();
        }, 1000);
      }
    }
  };

  const onSubmitResponseModal = () => {
    if (isRoleSME) {
      setTimeout(() => {
        const previousPath = sessionStorage.getItem("prevPath");

        if (previousPath) {
          navigate({ to: previousPath });
        } else {
          navigate({ to: location.pathname });
        }
      }, 1000);
    }
  };

  const postMessage = (message: string) => {
    if (zoningWindowRef.current != null) {
      localStorage.setItem("highlight", message);
      window.dispatchEvent(new Event("storage"));
    }
  };

  const documentField = watch("document");
  const serviceCodeWatch = watch("header.0.servicecode");
  watch((_, { type }) => {
    if (isFormSaved && type === "change") {
      setIsFormSaved(false);
    }
  });

  const extractedTexts = useMemo(() => {
    const headerValues = values?.header[0];
    // console.log("extractedTexts: ", values, headerValues);
    if (values != null) {
      return Object.keys(headerValues).map((d) => headerValues[d] as string);
    }
    return [];
  }, [values]);
  const sources = useMemo(() => {
    const zoning = data?.zoningdocuments;
    if (!zoning) {
      return { src: undefined, json: undefined, jsonData: undefined };
    }

    // Use new structure if available, fallback to legacy
    return {
      src: zoning.currentDocument?.imageUrl || zoning.imageurl,
      json: zoning.jsonurl,
      jsonData: zoning.currentDocument?.jsonData || zoning.jsonData,
    };
  }, [data?.zoningdocuments]);
  const handleSelect = useCallback(
    ({ text }: { text: string }) => {
      const selectedField = localStorage.getItem(SELECTED_FIELD);
      if (selectedField) {
        setValue(selectedField, text);
        void trigger(selectedField);
      }
    },
    [setValue, trigger],
  );

  useEffect(() => {
    if (serviceCodeWatch && allSchemas) {
      const shippingCode = getValues("header.0.shippingcode");
      if (shippingCode && shippingCode !== "Hazmat") {
        setFormFields(allFormFields![shippingCode]);
        setTableFields(allTableFields![shippingCode]);

        const section = allTableFields![shippingCode].find(
          (obj: any) => obj.label === "Line Item & DG Section",
        );
        if (section) {
          const field = section.fields.find(
            (f: any) => f.id === "lineitemnumber",
          );
          if (field) {
            field.validation.required = false;
          }
        }
      }
    }
  }, [
    serviceCodeWatch,
    control,
    allSchemas,
    allFormFields,
    setFormFields,
    setTableFields,
    allTableFields,
    trigger,
    reset,
    getValues,
  ]);

  const handleExtractionVersionChange = async (selectedVersion: any) => {
    setSelectedVersion(selectedVersion.target.value);

    if (!values || !values.header || values.header.length === 0) {
      console.error("Values or header is undefined or empty");
      return;
    }

    const taskId = values.header[0]["taskid"];
    const versionKey = selectedVersion?.target.value || "lastversion";

    try {
      setIsLoading(true);

      const response = (await getAgentTaskDetailsById(
        taskId,
        roleid,
        versionKey,
      )) as any;

      if (response.status) {
        const { data } = response;

        if (!data || !data.data.dbdata) {
          toast.error("Data is not available", {
            theme: "colored",
          });
          return;
        }
        reset();
        setValues(data.data.dbdata);

        reset({
          header: data.data.dbdata.header,
          table: data.data.dbdata.table,
        });

        await trigger();
      } else {
        console.error("Error fetching task details");
      }
    } catch (error) {
      console.error("Error during API call:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    window.addEventListener("message", (event) => {
      // if (event.origin !== import.meta.env.VITE_AWS_COGNITO_REDIRECT_URL) {
      //   return;
      // }
      async function tesseract() {
        const { dataURL }: { dataURL: string } = event.data;
        if (dataURL && dataURL !== "data:,") {
          const recognizedChars = await recognizeTextInImage(dataURL);
          const selectedField = localStorage.getItem(SELECTED_FIELD);
          if (recognizedChars && selectedField) {
            setValue(selectedField, recognizedChars.text.trim());
            await trigger(selectedField);
          }
        }
      }

      // Handle zoning page change from popup
      if (event.data?.type === "zoningPageChange") {
        const { index } = event.data;
        const doc = data?.zoningdocuments?.allDocuments?.[index];
        if (doc) {
          console.info("Navigating to document:", index);
          // Update sources with the new document
          // Note: The ZoningTriggerComponent will need to handle the document change
        }
      }

      // if (event.origin == import.meta.env.VITE_AWS_COGNITO_REDIRECT_URL) {
      void tesseract();
      // }
    });

    return () => {
      window.removeEventListener("message", () => {});
    };
  }, [setValue, trigger]);

  useEffect(() => {
    if (formSchema != null) {
      setIsSubmitModalOpen(false);
      // console.log(values);
      setValue("document", documents[0].DocumentName);
      setValue("header", values?.header);
      setValue("table", values?.table);
      // openZoningWindow();
      setPopupType("zoning");

      setIsFormSaved(false);
      setIsLoading(false);
      if (zoningWindowRef.current != null) {
        zoningWindowRef.current.postMessage(
          {
            type: "updateData",
            sources,
            extractedTexts: Object.keys(getValues("header.0")).map((d) =>
              getValues(`header.0.${d}`),
            ),
          },
          "*",
        );
      }
    }
  }, [
    formSchema,
    values,
    setValue,
    documents,
    data?.zoningdocuments,
    getValues,
  ]);

  useEffect(() => {
    setDocument(
      documents?.find(
        (document: any) => document.DocumentName === documentField,
      ),
    );
  }, [documentField, documents]);

  const handleDocumentModal = () => {
    setShowDocumentModal(true);
  };
  //  const serviceCodeWatch = useWatch({
  //    name: "header[0].servicecode", // Track changes in servicecode field
  //  });

  const onSubmit = async (d: any) => {
    console.log("onSubmit", d);
    // Custom Hazmat validation
    const shippingCode = d?.header?.[0]?.shippingcode;
    const tableEntity3 = d?.table?.tableentity3;
    if (
      shippingCode === "Hazmat" &&
      Array.isArray(tableEntity3) &&
      tableEntity3.length > 0
    ) {
      // Filter rows where commodityhazmatflag === "TRUE" (case-insensitive)
      const hazmatRows = tableEntity3.filter(
        (row: any) =>
          row?.commodityhazmatflag?.toString().toUpperCase() === "TRUE",
      );

      if (hazmatRows.length > 0) {
        // Check if any hazmat row has any of blank in below three fields.
        const invalidRows = hazmatRows.filter((row: any) => {
          const tech = row?.hazmatpropername?.toString().trim();
          const idnum = row?.hazmatidnumberunna?.toString().trim();
          const pack = row?.hazmatpackinggroup?.toString().trim();
          return !tech || !idnum || !pack;
        });

        if (invalidRows.length > 0) {
          toast.error(
            `For Hazmat, if any commodities are flagged TRUE,
              then for each Hazmat TRUE flagged row then Hazmat Proper Name,
                Hazmat ID Number/UNNA, and Hazmat PG (Packing Group) must be filled.`,
            { theme: "colored" },
          );
          return;
        }
      }
    }
    const tpId = d?.header?.[0]?.billtoid?.toString().trim();
    const tpName = d?.header?.[0]?.billtoname?.toString().trim();
    const tpAddress = d?.header?.[0]?.billtoaddress?.toString().trim();
    const tpAddress2 = d?.header?.[0]?.billtoaddress2?.toString().trim();
    const tpAddress3 = d?.header?.[0]?.billtoaddress3?.toString().trim();
    const tpPhone = d?.header?.[0]?.billtophone?.toString().trim();
    const tpPhoneExt = d?.header?.[0]?.billtophoneextension?.toString().trim();
    const tpEmail = d?.header?.[0]?.billtoemail?.toString().trim();
    const tpCity = d?.header?.[0]?.billtocity?.toString().trim();
    const tpState = d?.header?.[0]?.billtostate?.toString().trim();
    const tpZip = d?.header?.[0]?.billtozip?.toString().trim();
    const tpCountry = d?.header?.[0]?.billtocountry?.toString().trim();

    // If ANY Third Party field is filled → ALL fields must be filled
    if (
      tpId ||
      tpName ||
      tpAddress ||
      tpAddress2 ||
      tpAddress3 ||
      tpPhone ||
      tpPhoneExt ||
      tpEmail ||
      tpCity ||
      tpState ||
      tpZip ||
      tpCountry
    ) {
      if (
        !tpName ||
        !tpAddress ||
        !tpCity ||
        !tpState ||
        !tpZip ||
        !tpCountry
      ) {
        toast.error(
          `For Third Party, if any field is provided then all fields (Name, Address, City, State, Zip, Country) must be filled.
       Please fill all fields to continue.`,
          { theme: "colored" },
        );
        return;
      }
    }

    setIsSubmitting(true);

    d.header[0]["taskid"] = values.header[0]["taskid"];

    const saveData = await putAgentTaskDetails(
      Number(values.header[0]["taskid"]),
      roleid,
      {
        dbdata: { ...d },
      },
    );
    // console.log(saveData);
    if (saveData.status && (saveData.data as any).data === "success") {
      setIsFormSaved(true);
      setIsSubmitting(false);
      setIsLoading(false);
      const taskId = values.header[0]["taskid"];
      const versionKey = "lastversion";
      try {
        setIsLoading(true);

        const response = (await getAgentTaskDetailsById(
          taskId,
          roleid,
          versionKey,
        )) as {
          status: boolean;
          data: {
            data: {
              dbdata: {
                header: any;
                table: any;
              };
            };
          };
        };

        if (response.status) {
          const { data } = response;

          const businessRules =
            data?.data?.dbdata?.header?.[0]?.businessrulesobject;
          if (!data || !data.data.dbdata) {
            toast.error("Data is not available", {
              theme: "colored",
            });
            return;
          }
          if (roleid === "16" && Array.isArray(businessRules)) {
            businessRules.forEach((rule) => {
              toast.success(
                `Rule: ${rule.ruleid}, Source: ${rule.source},Rule Description:${rule.ruledescription}`,
                {
                  theme: "colored",
                },
              );
            });
          }
          reset();

          reset({
            header: data.data.dbdata.header,
            table: data.data.dbdata.table,
          });

          await trigger();
        } else {
          console.error("Error fetching task details");
        }
      } catch (error) {
        console.error("Error during API call:", error);
      } finally {
        setIsLoading(false);
      }
    } else {
      toast.error((saveData as any).data.message, {
        theme: "colored",
      });
      setIsFormSaved(false);
      setIsSubmitting(false);
    }
  };
  const raiseExceptionHandler = async (d: any) => {
    d.header[0]["taskid"] = values.header[0]["taskid"];

    const saveData = await putAgentTaskDetails(
      Number(values.header[0]["taskid"]),
      roleid,
      {
        dbdata: { ...d },
      },
    );

    if (saveData.status && (saveData.data as any).data === "success") {
      setIsFormSaved(true);
      setIsLoading(false);
    } else {
      toast.error((saveData as any).data.message, {
        theme: "colored",
      });
      setIsFormSaved(false);
    }
    return saveData;
  };

  const handleRaiseException = async () => {
    // Get shipping code for partial schema
    const shippingCode =
      getValues("header[0].shippingcode") || getValues("header.0.shippingcode");
    const schemaObj = partialSchemas?.type?.[shippingCode];
    // console.log("schemaObj", schemaObj);
    if (!schemaObj) return;
    try {
      // Validate with partial schema
      const result = await schemaObj.schema.safeParseAsync({
        header: getValues("header"),
        table: getValues("table"),
      });
      if (result.success) {
        stateUpdater(setIsOpen, true)();
      } else {
        // Set errors for each field
        toast.error(`Please clear the validation errors to proceed.`, {
          theme: "colored",
        });

        result.error.errors.forEach((err) => {
          // err.path example: ["header", 0, "fieldname"]
          if (
            Array.isArray(err.path) &&
            err.path.length >= 3 &&
            err.path[0] === "header"
          ) {
            const field = `header.${err.path[1]}.${err.path[2]}`;
            setError(field, { type: "manual", message: err.message });
          } else if (
            Array.isArray(err.path) &&
            err.path.length >= 3 &&
            err.path[0] === "table"
          ) {
            // Table errors: path = ["table", tablename, rowIndex, fieldname]
            const field = `table.${err.path[1]}.${err.path[2]}.${err.path[3]}`;
            setError(field, { type: "manual", message: err.message });
          }
        });
      }
    } catch (e) {
      // fallback: do nothing
      console.error("Validation error:", e);
    }
  };

  const onSubmitError = () => {
    trigger();
  };

  function setFormValuesWithPrefix(prefix: string, valuesObj: any) {
    // add custom conditions here
    if (prefix === "thirdparty") {
      prefix = "billto";
    }
    Object.entries(valuesObj).forEach(([key, value]) => {
      setValue(`header.0.${prefix}${key}`, value, { shouldValidate: true });
    });
  }

  if (formStatus == "INVALID") {
    return (
      <>
        {" "}
        <div>Form is invalid</div>
        <button>fetch next task</button>
      </>
    );
  }
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.ctrlKey && event.key.toLowerCase() === "s") {
        event.preventDefault();
        // console.log("CTRL + S pressed - Triggering Save");
        const saveBtn = window.document.getElementById("save-btn");
        saveBtn?.click();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [handleSubmit, onSubmit, onSubmitError]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.ctrlKey) {
        const key = event.key.toLowerCase();
        switch (key) {
          case "g":
            event.preventDefault();
            console.log("CTRL + G pressed-Confirm and Get Next Task");

            // console.log("isFormSaved:", isFormSaved);
            // console.log("isSubmitting:", isSubmitting);
            // console.log("isNextTaskEnabled:", isNextTaskEnabled);

            if (!isFormSaved || isSubmitting || !isNextTaskEnabled) {
              toast.info(
                `Save and Get next task button is disabled. Please save the form before submitting the task.`,
                {
                  theme: "colored",
                  position: "top-right",
                  autoClose: 5000,
                  hideProgressBar: false,
                  closeOnClick: false,
                  pauseOnHover: true,
                  draggable: true,
                  progress: undefined,
                  transition: Bounce,
                },
              );
              console.log(
                "Save and Get next is disabled. Task will not be submitted.",
              );
            } else {
              // stateUpdater(setIsSubmitModalOpen, true)();
              const saveBtn = window.document.getElementById("submitSaveBtn");
              saveBtn?.click();
            }
            break;

          case "e":
            event.preventDefault();
            console.log("CTRL + E pressed-Exception Window");
            stateUpdater(setIsOpen, true)();
            break;

          case "i":
            event.preventDefault();
            console.log(
              "CTRL + i pressed-Expand/Collapse Prompt Instructions area",
            );
            stateUpdater(setAreaExpand)();
            break;

          default:
            break;
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      setIsLoading(false);
    };
  }, [isFormSaved, isSubmitting, isNextTaskEnabled]);
  const enableVersionDropdown =
    process.env.VITE_ENABLE_VERSION_DROPDOWN === "true";
  const enableHoldButton = process.env.VITE_ENABLE_SME_HOLD_BUTTON === "true";
  // console.log(`enableHoldButton: ${enableHoldButton}`);
  return (
    <div
      className={cn(
        "w-full h-full flex flex-col",
        formSchema == null && "items-center justify-center",
      )}
    >
      {isLoading && (
        <div className="absolute inset-0 flex z-10 justify-center items-center">
          <div className="spinner-border animate-spin border-4 border-orange-400 border-t-transparent w-12 h-12 rounded-full"></div>
        </div>
      )}
      {formSchema != null && (
        <FormProvider {...agentForm}>
          <div className="flex flex-col md:flex-row space-x-2 mb-2">
            <div className="flex-1 bg-white">
              <TextAreaField
                title={documents?.[0]?.["TaskName"]}
                //key={`header.0.${f?.id}`}
                name={documents?.[0]?.["TaskName"]}
                label="Task Name"
                dataBlockId={"topLevel"}
                value={documents?.[0]?.["TaskName"]}
                rows={1}
              />
            </div>
            <div className="bg-white w-32">
              <TextAreaField
                title={documents?.[0]?.["TaskName"]}
                // key={data?.zoningdocuments?.imageurl?.[0]}
                name={documents?.[0]?.["TaskName"]}
                label="Number of Pages"
                value={data?.zoningdocuments?.jsonurl?.length}
                rows={1}
              />
            </div>
            {enableVersionDropdown && (
              <div className="flex-1 text-center">
                <SelectBox
                  label="Extraction versions"
                  className="text-center"
                  dataBlockId={"topLevel"}
                  name="Extraction Version"
                  onChange={handleExtractionVersionChange}
                  options={extractionVersion.map((version: any) => {
                    return {
                      key: version.value,
                      value: version.description,
                    };
                  })}
                  value={selectedVersion}
                />
              </div>
            )}
            <div className="flex-1">
              <SelectBox
                label="Documents"
                name="document"
                dataBlockId={"topLevel"}
                options={documents
                  ?.sort((a: any, b: any) => {
                    const extA = a.DocumentName.split(".").pop().toLowerCase();
                    const extB = b.DocumentName.split(".").pop().toLowerCase();
                    return extA.localeCompare(extB);
                  })
                  .map((document: any) => ({
                    key: document.DocumentName,
                    value: document.DocumentName,
                  }))}
                value={document?.DocumentName}
                onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                  setDocument(
                    documents?.find(
                      (document: any) =>
                        document.DocumentName === e.target.value,
                    ),
                  );
                  setPopupType("regular");
                  handleDocumentModal();
                }}
              />
            </div>
            <div className="flex-1">
              {!readOnly && (
                <div className="flex">
                  {!isRoleSME && (
                    <Button
                      type="button"
                      variant={"primary"}
                      size={"small"}
                      className="flex-1 text-sm rounded me-2 py-2"
                      // disabled={!!Object.keys(errors).length}
                      onClick={async () => handleRaiseException()}
                    >
                      Raise Exception
                    </Button>
                  )}

                  <div className="flex-1">
                    {" "}
                    <Timer />
                  </div>
                </div>
              )}
            </div>
          </div>
          <div className="w-full flex-grow overflow-y-hidden">
            <form
              className="w-full h-full flex flex-col"
              onSubmit={handleSubmit(onSubmit, onSubmitError)}
            >
              <>
                <Popover
                  type={popupType}
                  document={document}
                  extractedTexts={extractedTexts}
                  sources={sources}
                  onSelect={handleSelect}
                  allDocuments={data?.zoningdocuments?.allDocuments}
                  key={taskId}
                  // taskId={taskId}
                  // ref={popoverRef}
                />
                <div className="w-full h-full flex gap-2 overflow-hidden">
                  <>
                    <div className={cn(showSideBar ? "flex" : "hidden")}>
                      <Sidebar
                        activeSection={activeSection}
                        setActiveSection={setActiveSection}
                      />
                    </div>
                    <div
                      onClick={() => {
                        setShowSideBar(!showSideBar);
                      }}
                      className="button absolute top-3/4 left-0 cursor-pointer"
                    >
                      <img
                        width={17}
                        height={60}
                        src="/images/button.png"
                        alt=""
                      />
                    </div>
                    {!showSideBar && (
                      <div
                        onClick={() => {
                          setShowSideBar(!showSideBar);
                        }}
                        className="button absolute top-3/4 left-0 cursor-pointer"
                      >
                        <img
                          width={17}
                          height={60}
                          src="/images/button-2.png"
                          alt=""
                        />
                      </div>
                    )}
                    <div className="overflow-scroll w-full">
                      <HeaderFields
                        activeSection={activeSection}
                        setActiveSection={setActiveSection}
                        postMessage={postMessage}
                        tableRefs={agentTableRefs}
                        enableCountry={enableCountry}
                      />
                      <PromptsComponent
                        InitHeaderFields={data?.dbdata?.header[0]}
                        submitTrigger={submitTrigger}
                        expandCollapseArea={areaExpand}
                        setExpandCollapseArea={setAreaExpand}
                      />
                      {/* <AgentTables /> */}
                    </div>
                  </>
                </div>

                {readOnly && (
                  <div className="mt-2 flex justify-end sticky">
                    <Button
                      size={"medium"}
                      className="mr-2 text-sm"
                      type="button"
                      variant="secondary"
                      onClick={stateUpdater(setIsDocumentListModalOpen, true)}
                    >
                      Show Document List
                    </Button>
                  </div>
                )}

                {!readOnly && (
                  <div className="flex justify-between sticky">
                    <Button
                      className="mr-2 text-sm"
                      variant="secondary"
                      size={"medium"}
                      type="button"
                      onClick={stateUpdater(setIsHelpModalOpen, true)}
                    >
                      Help
                    </Button>
                    <div>
                      {isRoleSME && (
                        <Button
                          size={"medium"}
                          className="mr-2 text-sm"
                          type="button"
                          variant="secondary"
                          onClick={stateUpdater(setRespondModal, true)}
                        >
                          Respond to WNS SME
                        </Button>
                      )}
                      {isRoleWNSSME && enableHoldButton && (
                        <Button
                          size={"medium"}
                          className="mr-2 text-sm"
                          type="button"
                          variant="secondary"
                          onClick={stateUpdater(setWnsSMEHoldModal, true)}
                        >
                          Hold
                        </Button>
                      )}

                      {/* <Button
                          className="mr-2 text-sm hidden "
                          type="button"
                          size={"medium"}
                          variant="secondary"
                          onClick={openZoningWindow}
                        >
                          Zoning
                        </Button> */}
                      <Button
                        className="mr-2 text-sm"
                        type="button"
                        variant="secondary"
                        size={"medium"}
                        onClick={stateUpdater(setIsDocumentListModalOpen, true)}
                      >
                        Show Document List
                      </Button>
                      {ifBusinessRuleRole && (
                        <Button
                          size={"medium"}
                          className="mr-2 text-sm"
                          type="submit"
                          variant="secondary"
                        >
                          Apply Business Rule
                        </Button>
                      )}
                      {!ifBusinessRuleRole && (
                        <Button
                          className="mr-2 text-sm"
                          type="submit"
                          variant="secondary"
                          size={"medium"}
                          id="save-btn"
                          disabled={!!Object.keys(errors).length}
                        >
                          Save
                        </Button>
                      )}

                      {!ifBusinessRuleRole && (
                        <Button
                          id="submitSaveBtn"
                          className="mr-2 text-sm"
                          type="button"
                          size={"medium"}
                          onClick={sendAht}
                          disabled={
                            !isFormSaved ||
                            isSubmitting ||
                            !isNextTaskEnabled ||
                            !!Object.keys(errors).length
                          }
                        >
                          {isSubmitting ? (
                            <div className="flex items-center">
                              <span className="mr-2">Please wait..</span>
                            </div>
                          ) : (
                            "Submit and get next Task"
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                )}
              </>
              <HelpModal
                isOpen={isHelpModalOpen}
                onClose={stateUpdater(setIsHelpModalOpen, false)}
              />
              <DocumentListModal
                isOpen={isDocumentListModalOpen}
                onClose={stateUpdater(setIsDocumentListModalOpen, false)}
                documents={documents}
              />
              <ExceptionModal
                isOpen={isOpen}
                onClose={stateUpdater(setIsOpen, false)}
                setActiveTab={setActiveTab}
                form={agentForm}
                onPartialSubmit={raiseExceptionHandler}
              />
              <ResponseModal
                isOpen={respondModal}
                onClose={stateUpdater(setRespondModal, false)}
                onSubmit={onSubmitResponseModal}
              />
              <SMEHoldModal
                isOpen={wnsSMEHoldModal}
                onClose={stateUpdater(setWnsSMEHoldModal, false)}
                setActiveTab={setActiveTab}
                form={agentForm}
              />
              <SubmitModal
                isOpen={isSubmitModalOpen}
                onClose={stateUpdater(setIsSubmitModalOpen, false)}
                setActiveTab={setActiveTab}
                form={agentForm}
              />
              <SearchModal
                show={isSearchModalOpen}
                onClose={stateUpdater(setIsSearchModalOpen, false)}
                zip={zip}
                state={stateValue}
                name={name}
                city={city}
                address1={address1}
                accountNumber={accountNumber}
                taskid={taskId}
                requestSource={searchSource}
                onRowSelect={(record) => {
                  if (!record) return; // Prevents errors if record is null or undefined
                  if (isValidParty(searchSource?.toLowerCase())) {
                    setFormValuesWithPrefix(searchSource?.toLowerCase(), {
                      id: record.account_code,
                      [searchSource?.toLowerCase() === "thirdparty"
                        ? "name"
                        : ""]: record.name,
                      address: record.addr_1,
                      address2: record.addr_2,
                      address3: record.addr_3,
                      city: record.city,
                      state: record.state,
                      zip: record.zip,
                    });

                    if (searchSource?.toLowerCase() === "thirdparty") {
                      setValue("header.0.billtocountry", "");
                      setEnableCountry((prev) => ({
                        field: "billtocountry",
                        count: prev.count + 1,
                      }));
                    } else if (searchSource?.toLowerCase() === "consignee") {
                      setValue("header.0.consigneecountry", "");
                      setEnableCountry((prev) => ({
                        field: "consigneecountry",
                        count: prev.count + 1,
                      }));
                    } else if (searchSource?.toLowerCase() === "shipper") {
                      setValue("header.0.shippercountry", "");
                      setEnableCountry((prev) => ({
                        field: "shippercountry",
                        count: prev.count + 1,
                      }));
                    }
                  }
                }}
              />

              <ZipSearchModal
                show={isZipSearchModalOpen}
                onClose={stateUpdater(setIsZipSearchModalOpen, false)}
                zip={zip}
                state={stateValue}
                city={city}
                displayValue={zipPopupHeaderDisplay}
                onRowSelect={(record) => {
                  if (!record) return; // Prevents errors if record is null or undefined
                  if (isValidParty(searchSource?.toLowerCase())) {
                    setFormValuesWithPrefix(searchSource?.toLowerCase(), {
                      city: record.city,
                      state: record.state,
                      zip: record.zipcode,
                    });
                  }
                }}
              />
            </form>
          </div>
        </FormProvider>
      )}
    </div>
  );
};

export default AgentForm;
