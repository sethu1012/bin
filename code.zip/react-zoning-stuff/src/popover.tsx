import { useEffect, useRef } from "react";
import ReactDOM from "react-dom/client";
import TiffViewer from "./tiff-viewer";
import ZoningTriggerComponent from "./zoning";
import { CustomBlock } from "./zoning-canvas";

export interface IPopoverProps {
  type: "zoning" | "regular";
  document: {
    BucketURL?: string;
    DocumentName?: string;
    S3bucketName?: string;
    ShippingCode?: string;
    Status?: string;
    TaskDocumentID?: string;
    TaskId?: string;
    TaskName?: string;
    presigned_url: string;
  };
  sources: { src: string[]; json: string[]; jsonData: any };
  extractedTexts: string[];
  onSelect: ({ text, line }: { text: string; line: CustomBlock }) => void;
  // NEW: Pagination props
  allDocuments?: Array<{
    index: number;
    imageUrl: string; // blob URL
    jsonData: any;
  }>;
}

const Popover = ({
  type = "zoning",
  document,
  sources,
  extractedTexts,
  onSelect,
  allDocuments,
}: IPopoverProps) => {
  // console.log("Rendering Popover Component");
  // console.log({ type, document, sources, extractedTexts });
  const imageWinRef = useRef<Window | null>(null);

  useEffect(() => {
    if (document == null) return;
    let imageWindow: Window | null;

    if (imageWinRef.current && !imageWinRef.current.closed) {
      imageWindow = imageWinRef.current;
    } else {
      imageWindow = window.open(
        "",
        "ImagePopup",
        `same-origin=true,allow-scripts,allow-same-origin,width=${screen.width},height=${screen.height}`,
      );
      imageWinRef.current = imageWindow;
    }

    if (!imageWindow) return;
    const imageWindowDocument = imageWindow.document;

    const isPDF = document?.DocumentName?.toLowerCase().endsWith(".pdf");
    const isTiff = /\.(tif{1,2}$)/i.test(document?.DocumentName || "");
    const isJSON = document?.DocumentName?.toLowerCase().endsWith(".json");
    const docType = document?.DocumentName?.split(".")[1];
    const fileName = document?.DocumentName || "";
    const imageUrl = document?.presigned_url;

    // ZONING: React canvas in popup
    if (type === "zoning") {
      imageWindowDocument.open();
      imageWindowDocument.write(`
        <html>
          <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <title>Zoning Trigger</title>
            <script>
              window.onload = function() {
                document.documentElement.style.zoom = "100%";
                document.body.style.transform = 'scale(1)';
                document.body.style.transformOrigin = '0 0';

                // Pagination setup
                const totalDocs = window.allDocuments?.length || 1;
                let currentIndex = 0;

                const firstBtn = document.getElementById("first-btn");
                const prevBtn = document.getElementById("prev-btn");
                const nextBtn = document.getElementById("next-btn");
                const lastBtn = document.getElementById("last-btn");
                const indicator = document.getElementById("doc-indicator");

                function updatePagination() {
                  firstBtn.disabled = currentIndex === 0;
                  prevBtn.disabled = currentIndex === 0;
                  nextBtn.disabled = currentIndex === totalDocs - 1;
                  lastBtn.disabled = currentIndex === totalDocs - 1;
                  indicator.textContent = currentIndex + 1 + " / " + totalDocs;
                }

                function showDocument(index) {
                  const doc = window.allDocuments[index];
                  if (!doc) return;
                  currentIndex = index;
                  updatePagination();
                  // Trigger document change event for parent to handle
                  if (window.opener && !window.opener.closed) {
                    window.opener.postMessage({
                      type: "zoningPageChange",
                      index: index,
                    }, "*");
                  }
                }

                if (firstBtn) firstBtn.addEventListener("click", () => showDocument(0));
                if (prevBtn) prevBtn.addEventListener("click", () => showDocument(Math.max(0, currentIndex - 1)));
                if (nextBtn) nextBtn.addEventListener("click", () => showDocument(Math.min(totalDocs - 1, currentIndex + 1)));
                if (lastBtn) lastBtn.addEventListener("click", () => showDocument(totalDocs - 1));

                // Initialize pagination
                updatePagination();

                var rotateBtn = document.getElementById("rotate-btn");
                if (rotateBtn) {
                  rotateBtn.addEventListener("click", function () {
                    window.dispatchEvent(new CustomEvent("rotate-canvas"));
                  });
                }
              }
            </script>
            <script>
              window.allDocuments = ${JSON.stringify(allDocuments || [])};
              window.totalDocs = ${allDocuments?.length || 1};
            </script>
            <style>
              * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
              }
              // #react-root, canvas {
              //   width: 100%;
              //   height: 100%;
              //   display: block;
              // }
              body {
                  background-color: #F5F5F5;
              }
                canvas {
                    display: block;
                    width: 100vw;
                    height: calc(100vh - 60px); /* Subtract header height */
                }

              .button-container {
                  // position: fixed;
                  top: 0;
                  width: 100vw;
                  background-color: #F5F5F5;
                  display: flex;
                  align-items: center;
                  justify-content: end;
                  padding: 0 2vw;
                  box-sizing: border-box;
                  z-index: 1000;
                  flex-wrap: wrap;
                  gap: 8px;
                }
                .pagination-controls {
                  display: flex;
                  align-items: center;
                  gap: 5px;
                }
                .nav-btn {
                  padding: 5px 10px;
                  border-radius: 6px;
                  border: 1px solid #ccc;
                  background: #ffffff;
                  cursor: pointer;
                  font-size: 12px;
                }
                .nav-btn:disabled {
                  opacity: 0.5;
                  cursor: not-allowed;
                }
                .doc-indicator {
                  font-size: 12px;
                  font-weight: 600;
                  margin: 0 5px;
                }
                .file-type-badge {
                  background-color: #000000;
                  opacity: 0.8;
                  border-radius: 6px;
                  padding: 5px;
                  margin: 5px;
                  width: fit-content;
                  color: white;
                  font-weight: bold;
                }
         .rotate-button {
            padding: 5px 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            background: #ffffff;
            cursor: pointer;
            font-size: 12px;
          }
        </style>
      </head>
      <body>
        <div class="button-container">
          <div class="pagination-controls">
            <button id="first-btn" class="nav-btn">&laquo; First</button>
            <button id="prev-btn" class="nav-btn">&lsaquo; Prev</button>
            <span id="doc-indicator" class="doc-indicator">1 / 1</span>
            <button id="next-btn" class="nav-btn">Next &rsaquo;</button>
            <button id="last-btn" class="nav-btn">Last &raquo;</button>
          </div>
          <button id="rotate-btn" class="rotate-button">Rotate</button>
          <div class="file-type-badge">Zoning PNG Image</div>
        </div>
            <div id="react-root"></div>
          </body>
        </html>
      `);
      imageWindowDocument.close();

      if (imageWindowDocument && sources.jsonData) {
        ReactDOM.createRoot(
          imageWindowDocument.getElementById("react-root")!,
        ).render(
          <ZoningTriggerComponent
            onSelect={onSelect}
            extractedTexts={extractedTexts}
            sources={{
              src: sources.src,
              json: sources.jsonData,
            }}
            popupWindow={imageWindow}
            allDocuments={allDocuments}
          />,
        );
      }
      return;
    }

    // PDF: simple iframe
    if (isPDF) {
      imageWindowDocument.open();
      imageWindowDocument.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>${fileName}</title>
            <style>
              html, body {
                margin: 0;
                padding: 0;
                height: 100%;
                overflow: hidden;
              }
              iframe {
                width: 100%;
                height: 100%;
                border: none;
              }
            </style>
          </head>
          <body>
            <iframe
              src="${document.presigned_url}"
              type="application/pdf"
            ></iframe>
          </body>
        </html>
      `);
      imageWindowDocument.close();
      return;
    }

    // JSON: simple pretty viewer with zoom + search
    if (isJSON && imageWindowDocument) {
      imageWindowDocument.open();
      imageWindowDocument.write(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="utf-8" />
      <title>${fileName}</title>
      <script>
        window.onload = function () {
          document.documentElement.style.zoom = "100%";
        }
      </script>
      <style>
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        body {
          height: 100vh;
          width: 100vw;
          display: flex;
          flex-direction: column;
          font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        }
        .toolbar {
          flex: 0 0 auto;
          height: 48px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 12px;
          background: #f5f5f5;
          border-bottom: 1px solid #ddd;
          gap: 8px;
        }
        .toolbar-left {
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .toolbar-title {
          font-size: 14px;
          font-weight: 600;
          color: #333;
        }
        .badge {
          font-size: 11px;
          padding: 2px 6px;
          border-radius: 4px;
          background: #111;
          color: #fff;
        }
        .toolbar-right {
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .btn {
          padding: 4px 8px;
          font-size: 12px;
          border-radius: 4px;
          border: 1px solid #ccc;
          background: #fff;
          cursor: pointer;
        }
        .btn:hover {
          background: #eee;
        }
        .search-input {
          font-size: 12px;
          padding: 4px 8px;
          border-radius: 4px;
          border: 1px solid #ccc;
          width: 200px;
        }
        .content {
          flex: 1 1 auto;
          overflow: auto;
          background: #1e1e1e;
          color: #d4d4d4;
        }
        pre {
          margin: 0;
          padding: 12px;
          font-family: "JetBrains Mono", Menlo, Monaco, Consolas, monospace;
          font-size: 13px;
          line-height: 1.5;
          white-space: pre;
        }
        mark {
          background: #ffd54f;
          color: #000;
        }
      </style>
    </head>
    <body>
      <div class="toolbar">
        <div class="toolbar-left">
          <span class="toolbar-title">${fileName}</span>
          <span class="badge">JSON</span>
        </div>
        <div class="toolbar-right">
          <input
            id="searchInput"
            class="search-input"
            type="text"
            placeholder="Search (press Enter)"
          />
          <button class="btn" id="copyBtn">Copy</button>
          <button class="btn" id="resetZoomBtn">Reset Zoom</button>
        </div>
      </div>
      <div class="content">
        <pre id="jsonView">{ loading: true }</pre>
      </div>
      <script>
        const jsonUrl = "${document?.presigned_url}";
        const pre    = document.getElementById("jsonView");
        const searchInput = document.getElementById("searchInput");
        const copyBtn     = document.getElementById("copyBtn");
        const resetZoomBtn = document.getElementById("resetZoomBtn");

        let rawText = "";
        let currentZoom = 1; // 1 = 100%
        const baseFontSize = 13;

        function applyZoom() {
          const size = baseFontSize * currentZoom;
          pre.style.fontSize = size + "px";
        }

        async function loadJson() {
          try {
            pre.textContent = "Loading JSON...";
            const res = await fetch(jsonUrl);
            if (!res.ok) {
              pre.textContent = "Failed to load JSON: " + res.status;
              return;
            }
            const data = await res.json();
            rawText = JSON.stringify(data, null, 2);
            pre.textContent = rawText;
          } catch (err) {
            pre.textContent = "Error: " + err;
          }
        }

        function highlightSearch(term) {
          if (!rawText || !term.trim()) {
            pre.textContent = rawText || "";
            return;
          }
          const esc = term.replace(/[.*+?^()|[\\]\\\\]/g, "\\\\$&");
          const regex = new RegExp(esc, "gi");
          const html = rawText.replace(regex, (m) => "<mark>" + m + "</mark>");
          pre.innerHTML = html;
        }

        searchInput.addEventListener("keydown", (e) => {
          if (e.key === "Enter") {
            highlightSearch(searchInput.value);
          }
        });

        copyBtn.addEventListener("click", async () => {
          try {
            await navigator.clipboard.writeText(rawText || pre.textContent || "");
            copyBtn.textContent = "Copied!";
            setTimeout(() => (copyBtn.textContent = "Copy"), 1000);
          } catch (e) {
            alert("Copy failed");
          }
        });

        resetZoomBtn.addEventListener("click", () => {
          currentZoom = 1;
          applyZoom();
        });

        // Ctrl + wheel zoom
        window.addEventListener(
          "wheel",
          (e) => {
            if (!e.ctrlKey) return;
            e.preventDefault();
            const factor = e.deltaY > 0 ? 0.9 : 1.1;
            const next = currentZoom * factor;
            if (next >= 0.5 && next <= 3) {
              currentZoom = next;
              applyZoom();
            }
          },
          { passive: false }
        );

        // Ctrl + +/- / 0 zoom
        window.addEventListener("keydown", (e) => {
          if (!e.ctrlKey) return;
          if (e.key === "-" || e.key === "_") {
            e.preventDefault();
            currentZoom = Math.max(0.5, currentZoom - 0.1);
            applyZoom();
          } else if (e.key === "+" || e.key === "=") {
            e.preventDefault();
            currentZoom = Math.min(3, currentZoom + 0.1);
            applyZoom();
          } else if (e.key === "0") {
            e.preventDefault();
            currentZoom = 1;
            applyZoom();
          }
        });

        loadJson();
        applyZoom();
      </script>
    </body>
    </html>
  `);
      imageWindowDocument.close();
      return;
    }

    // TIFF: React tiff-trigger inside popup shell
    if (isTiff) {
      imageWindowDocument.open();
      imageWindowDocument.write(`
        <html>
          <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <title>${fileName}</title>
            <script>
            </script>
            <style>
              * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
              }
            </style>
            <style>
              .button-container {
                top: 0;
                width: 100vw;
                background-color: #F5F5F5;
                display: flex;
                align-items: center;
                justify-content: end;
                padding: 0 2vw;
                box-sizing: border-box;
                z-index: 1000;
              }
              .file-type-badge {
                background-color: #000000;
                opacity: 0.8;
                border-radius: 6px;
                padding: 5px;
                margin: 5px;
                width: fit-content;
                color: white;
                font-weight: bold;
              }
            </style>
          </head>
          <body>
            <div class="button-container">
              <div class="file-type-badge">Combine ${docType} Image</div>
            </div>
            <div id="react-root"></div>
          </body>
        </html>
      `);
      imageWindowDocument.close();

      ReactDOM.createRoot(
        imageWindowDocument.getElementById("react-root")!,
      ).render(
        <TiffViewer
          src={
            process.env.NODE_ENV === "development"
              ? "/temp/tifffff.tiff"
              : document.presigned_url
          }
        />,
      );
      return;
    }

    // DEFAULT (e.g. PNG): pure HTML + canvas + internal zoom/rotate/select
    imageWindowDocument.open();
    imageWindowDocument.write(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <base href="${window.location.origin}">
        <title>${fileName}</title>
        <script>
          window.onload = function() {
            document.documentElement.style.zoom = "100%";
          }
        </script>
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          body {
            height: 100vh;
            width: 100vw;
          }
          canvas {
            display: block;
            margin-top: 60px;
            width: 100vw;
            height: calc(100vh - 60px);
          }
          .button-container {
            position: fixed;
            top: 0;
            height: 8vh;
            width: 100vw;
            background-color: #F5F5F5;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 1vw;
            padding: 0 2vw;
            box-sizing: border-box;
            z-index: 1000;
          }
          .btn {
            padding: 2vh;
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 46%;
            font-size: 2vh;
            transition: background-color 0.3s;
          }
          .btn:hover {
            background-color: rgba(0, 0, 0, 0.7);
          }
          .btn:last-child {
            padding: 2vh 3vh;
            border-radius: 4vh;
          }
            .button-container {
          position: fixed;
          top: 0;
          width: 100vw;
          background-color: #F5F5F5;
          display: flex;
          align-items: center;
          justify-content: end;
          padding: 0 2vw;
          box-sizing: border-box;
          z-index: 1000;
        }
        .file-type-badge {
          background-color: #000000;
          opacity: 0.8;
          border-radius: 6px;
          padding: 5px;
          margin: 5px;
          width: fit-content;
          color: white;
          font-weight: bold;
        }
        </style>
      </head>
      <body>
        <div class="button-container">
          <button class="btn" id="rotateBtn">⟳</button>
          <button class="btn" id="downloadBtn">⇩ Download</button>
        <div class="file-type-badge">Combine ${docType} Image</div>
        </div>
        <canvas id="drawingCanvas"></canvas>
        <script>
          function initCanvas() {
            const canvas = document.getElementById("drawingCanvas");
            const ctx = canvas.getContext("2d");
            const img = new Image();
            img.crossOrigin = "anonymous";
            img.src = "${imageUrl}";

            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';

            const dpr = window.devicePixelRatio || 1;
            let currentZoom = 1;
            let angle = 0;



function drawImage() {
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight - 60; // still useful for feeling
  const dpr = window.devicePixelRatio || 1;

  const imgW = img.width;
  const imgH = img.height;

  const isRotated = angle % 180 !== 0;

  // When rotated, logical source dims swap
  const srcW = isRotated ? imgH : imgW;
  const srcH = isRotated ? imgW : imgH;

  // 🔹 Always fit to width (not contain)
  const baseScale = viewportWidth / srcW; // this guarantees full width
  const totalScale = baseScale * currentZoom;

  const drawWidth = srcW * totalScale;      // ~ viewportWidth * currentZoom
  const drawHeight = srcH * totalScale;     // may be taller than viewport → scroll

  // Canvas internal size in physical pixels
  canvas.width = drawWidth * dpr;
  canvas.height = drawHeight * dpr;

  // CSS size in display pixels
  canvas.style.width = drawWidth + "px";
  canvas.style.height = drawHeight + "px";

  // Reset transform each time
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, drawWidth, drawHeight);
  ctx.save();

  // Center + rotate
  ctx.translate(drawWidth / 2, drawHeight / 2);
  ctx.rotate((angle * Math.PI) / 180);

  // Box size in the rotated space
  const boxW = isRotated ? drawHeight : drawWidth;
  const boxH = isRotated ? drawWidth : drawHeight;

  ctx.drawImage(img, -boxW / 2, -boxH / 2, boxW, boxH);

  ctx.restore();
}

            img.onload = drawImage;

            document
              .querySelector(".button-container")
              .addEventListener("click", function (event) {
                if (!event.target.classList.contains("btn")) return;

                if (event.target.id === "rotateBtn") {
                  angle = (angle + 90) % 360;
                  drawImage();
                } else if (event.target.id === "downloadBtn") {
                  const link = document.createElement("a");
                  link.download = "${fileName || "downloaded_image.png"}";
                  link.href = canvas.toDataURL("image/png");
                  link.click();
                }
              });

            let isDrawing = false;
            let startX = 0;
            let startY = 0;

            canvas.addEventListener("mousedown", (e) => {
              const rect = canvas.getBoundingClientRect();
              isDrawing = true;
              startX = e.clientX - rect.left;
              startY = e.clientY - rect.top;
            });

            canvas.addEventListener("mousemove", (e) => {
              if (!isDrawing) return;

              const rect = canvas.getBoundingClientRect();
              const currentX = e.clientX - rect.left;
              const currentY = e.clientY - rect.top;

              drawImage();

              ctx.beginPath();
              ctx.rect(startX, startY, currentX - startX, currentY - startY);
              ctx.strokeStyle = "red";
              ctx.stroke();
            });

            canvas.addEventListener("mouseup", (e) => {
              if (!isDrawing) return;

              const rect = canvas.getBoundingClientRect();
              const currentX = e.clientX - rect.left;
              const currentY = e.clientY - rect.top;

              const x = Math.min(startX, currentX);
              const y = Math.min(startY, currentY);
              const width = Math.abs(currentX - startX);
              const height = Math.abs(currentY - startY);

              const tempCanvas = document.createElement("canvas");
              const tempCtx = tempCanvas.getContext("2d");
              tempCanvas.width = width;
              tempCanvas.height = height;
              tempCtx.drawImage(
                canvas,
                x * dpr,
                y * dpr,
                width * dpr,
                height * dpr,
                0,
                0,
                width,
                height
              );

              const dataURL = tempCanvas.toDataURL();
              window.opener.postMessage({ dataURL }, "*");

              isDrawing = false;
            });

            // Ctrl + wheel zoom
            canvas.addEventListener(
              "wheel",
              (e) => {
                if (!e.ctrlKey) return;
                e.preventDefault();

                const zoomAmount = 0.1;
                const zoomFactor = e.deltaY > 0 ? 1 - zoomAmount : 1 + zoomAmount;
                const newZoom = currentZoom * zoomFactor;

                if (newZoom >= 0.5 && newZoom <= 5) {
                  currentZoom = newZoom;
                  drawImage();
                }
              },
              { passive: false }
            );

            // Ctrl + +/- / 0 zoom
            window.addEventListener("keydown", (e) => {
              if (!e.ctrlKey) return;

              if (e.key === "-") {
                e.preventDefault();
                currentZoom = Math.max(0.5, currentZoom - 0.1);
                drawImage();
              } else if (e.key === "=" || e.key === "+") {
                e.preventDefault();
                currentZoom = Math.min(5, currentZoom + 0.1);
                drawImage();
              } else if (e.key === "0") {
                e.preventDefault();
                currentZoom = 1;
                drawImage();
              }
            });

            window.addEventListener("resize", drawImage);
          }

          setTimeout(initCanvas, 200);
        </script>
      </body>
      </html>
    `);
    imageWindowDocument.close();
  }, [document, extractedTexts, onSelect, sources, type]);

  useEffect(() => {
    return () => {
      // Optional: don’t auto-close popup
      // imageWindow?.close();
      console.log("Inside 1");
      if (imageWinRef.current && !imageWinRef.current.closed) {
        console.log("Inside 2");
        const doc = imageWinRef.current.document;
        doc.open();
        doc.write("");
        doc.close();
      }
    };
  }, []);

  return null;
};

export default Popover;
