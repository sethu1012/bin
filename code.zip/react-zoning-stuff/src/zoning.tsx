import {
  TextractDocument,
  type ApiBlock,
} from "amazon-textract-response-parser";
import { useCallback, useEffect, useRef, useState } from "react";

type Sources = {
  src: string[];
  json: any;
};

interface IZoningComponentProps {
  onSelect: ({ text, line }: { text: string; line: CustomBlock }) => void;
  extractedTexts: string[];
  sources: Sources;
  zoningSearch: string;
  popupWindow: any;
}

export interface CustomBlock {
  text?: string;
  left: number;
  top: number;
  width: number;
  height: number;
}

type CustomApiBlock = ApiBlock & {
  Text: string;
};

type CustomBlockWithText = CustomBlock & { text: string };

/**
 * Geometry helper – mirrors your "combine" viewer logic.
 * Always fits to width, supports rotation, allows vertical scroll.
 */
function getDrawGeometry(img: HTMLImageElement, rotation: number) {
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight - 60; // header height

  const imgW = img.width;
  const imgH = img.height;

  const isRotated = rotation % 180 !== 0;

  // When rotated, logical source dims swap
  const srcW = isRotated ? imgH : imgW;
  const srcH = isRotated ? imgW : imgH;

  // Always fit to width (like your combine code)
  const baseScale = viewportWidth / srcW;
  const scale = baseScale; // no extra zoom in zoning

  const drawWidth = srcW * scale;   // CSS width of canvas
  const drawHeight = srcH * scale;  // CSS height of canvas (may be taller than viewport)

  // Box where image is drawn after rotation
  const boxW = isRotated ? drawHeight : drawWidth;
  const boxH = isRotated ? drawWidth : drawHeight;

  return {
    viewportWidth,
    viewportHeight,
    imgW,
    imgH,
    isRotated,
    srcW,
    srcH,
    scale,
    drawWidth,
    drawHeight,
    boxW,
    boxH,
  };
}

export default function ZoningComponent({
  onSelect,
  extractedTexts,
  sources,
  zoningSearch,
  popupWindow,
}: IZoningComponentProps) {
  const [textractData, setTextractData] = useState<TextractDocument>();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(new Image());
  const isDrawingRef = useRef<boolean>(false);
  const isDrawingInProgressRef = useRef<boolean>(false);
  const startPosRef = useRef<Record<string, number>>({ x: 0, y: 0 });
  const [activeField, setActiveField] = useState<string | null>();
  const [dimensionsSetup, setDimensionsSetup] = useState(false); // kept, even if unused
  const [rotation, setRotation] = useState(0); // 0,90,180,270

  // Load Textract + reset zoom
  useEffect(() => {
    void (async () => {
      if (sources?.src?.length === 0) return;
      const doc = new TextractDocument(sources?.json);
      setTextractData(doc);

      document.documentElement.style.zoom = "100%";
      document.body.style.transform = "scale(1)";
      document.body.style.transformOrigin = "0 0";
    })();
  }, [sources]);

  /**
   * Draw base image + textract blocks with rotation.
   * Uses the same geometry as your combine viewer.
   */
  const drawImageAndBlocks = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    const img = imageRef.current;
    const doc = textractData;

    if (!canvas || !ctx || !doc || !img.width || !img.height) return;

    const dpr = window.devicePixelRatio || 1;
    const angleRad = (rotation * Math.PI) / 180;

    const {
      drawWidth,
      drawHeight,
      boxW,
      boxH,
      scale,
    } = getDrawGeometry(img, rotation);

    // Internal canvas pixels
    canvas.width = drawWidth * dpr;
    canvas.height = drawHeight * dpr;

    // CSS display size
    canvas.style.width = `${drawWidth}px`;
    canvas.style.height = `${drawHeight}px`;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, drawWidth, drawHeight);

    ctx.save();
    ctx.translate(drawWidth / 2, drawHeight / 2);
    ctx.rotate(angleRad);

    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";

    // Draw image into boxW x boxH, centered
    ctx.drawImage(img, -boxW / 2, -boxH / 2, boxW, boxH);

    // Helper to draw a Textract bbox
    const drawBBox = (
      leftNorm: number,
      topNorm: number,
      widthNorm: number,
      heightNorm: number,
      opts: { stroke: string; fill?: string }
    ) => {
      const x = leftNorm * boxW - boxW / 2;
      const y = topNorm * boxH - boxH / 2;
      const w = widthNorm * boxW;
      const h = heightNorm * boxH;

      ctx.beginPath();
      ctx.rect(x, y, w, h);
      ctx.strokeStyle = opts.stroke;
      ctx.lineWidth = 1 / scale;
      if (opts.fill) {
        ctx.fillStyle = opts.fill;
        ctx.fill();
      }
      ctx.stroke();
      ctx.closePath();
    };

    const customLines = textractData
      .listBlocks()
      .filter(
        (block) => block.BlockType === "LINE" || block.BlockType === "WORD"
      )
      .filter((block) => (block as CustomApiBlock).Text)
      .map((line) => {
        if (line.Geometry?.BoundingBox == null) return null;
        const { Left, Top, Width, Height } = line.Geometry.BoundingBox;
        return {
          text: (line as CustomApiBlock).Text,
          left: Left,
          top: Top,
          width: Width,
          height: Height,
        } as CustomBlockWithText;
      })
      .filter((item) => item != null) as CustomBlockWithText[];

    // Highlight extracted + active + zoningSearch
    customLines
      .filter((block) => extractedTexts?.includes(block.text))
      .some((line) => {
        const { left, top, width, height, text } = line;

        let stroke = "red";
        let fill: string | undefined;

        if (text === activeField) {
          fill = "rgba(255, 255, 0, 0.3)";
        } else if (text.toLowerCase() === zoningSearch.toLowerCase()) {
          stroke = "green";
          fill = "rgba(255, 255, 0, 0.3)";
        }

        drawBBox(left, top, width, height, { stroke, fill });
        return false;
      });

    if (zoningSearch.trim().length > 0) {
      customLines.some((line) => {
        const { left, top, width, height, text } = line;

        if (text.toLowerCase() === zoningSearch.toLowerCase()) {
          drawBBox(left, top, width, height, {
            stroke: "green",
            fill: "rgba(255, 255, 0, 0.3)",
          });
          return true;
        }
        return false;
      });
    }

    ctx.restore();
  }, [activeField, extractedTexts, textractData, zoningSearch, rotation]);

  /**
   * Convert mouse position (view) → normalized image coords (0..1,0..1)
   * Inverts the same transform used in drawImageAndBlocks.
   */
  const viewToNormalized = useCallback(
    (e: MouseEvent) => {
      const canvas = canvasRef.current;
      const img = imageRef.current;
      if (!canvas || !img.width || !img.height) return null;

      const rect = canvas.getBoundingClientRect();
      const xView = e.clientX - rect.left;
      const yView = e.clientY - rect.top;

      const { drawWidth, drawHeight, imgW, imgH, boxW, boxH } =
        getDrawGeometry(img, rotation);

      // centre coords (same origin as drawing)
      const cx = xView - drawWidth / 2;
      const cy = yView - drawHeight / 2;

      // undo rotation
      const angle = (-rotation * Math.PI) / 180;
      const cos = Math.cos(angle);
      const sin = Math.sin(angle);

      const rx = cos * cx - sin * cy;
      const ry = sin * cx + cos * cy;

      // back to box space → image space
      const imgX = ((rx + boxW / 2) / boxW) * imgW;
      const imgY = ((ry + boxH / 2) / boxH) * imgH;

      let u = imgX / imgW;
      let v = imgY / imgH;

      u = Math.min(1, Math.max(0, u));
      v = Math.min(1, Math.max(0, v));

      return { u, v };
    },
    [rotation]
  );

  const extractText = useCallback(
    (line: CustomBlock) => {
      const isBlockWithin = (
        block: ApiBlock,
        left: number,
        top: number,
        width: number,
        height: number
      ) => {
        if (!block.Geometry || textractData == null) return false;
        const bb = block.Geometry.BoundingBox;
        const blockLeft = bb.Left;
        const blockTop = bb.Top;
        const blockWidth = bb.Width;
        const blockHeight = bb.Height;

        const right = left + width;
        const bottom = top + height;
        const blockRight = blockLeft + blockWidth;
        const blockBottom = blockTop + blockHeight;

        return (
          blockLeft < right &&
          blockRight > left &&
          blockTop < bottom &&
          blockBottom > top
        );
      };

      const getTextFromBlocks = (
        left: number,
        top: number,
        width: number,
        height: number
      ) => {
        if (textractData == null) return "";
        const data = textractData
          .listBlocks()
          .filter(
            (block) =>
              block.BlockType === "WORD" &&
              isBlockWithin(block, left, top, width, height)
          )
          .filter((block) => (block as CustomApiBlock).Text.trim() !== "")
          .map((block) => (block as CustomApiBlock).Text)
          .join(" ");
        return data.trim();
      };

      if (textractData != null && textractData?.listBlocks().length > 0) {
        const text = getTextFromBlocks(
          line.left,
          line.top,
          line.width,
          line.height
        ).trim();
        return { text, line };
      }
      return { text: "", line };
    },
    [textractData]
  );

  const handleMouseDown = useCallback(
    (e: MouseEvent) => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      const pos = viewToNormalized(e);
      if (!pos) return;

      isDrawingRef.current = true;
      isDrawingInProgressRef.current = true;

      startPosRef.current = {
        x: pos.u,
        y: pos.v,
      };
    },
    [viewToNormalized]
  );

  const handleMouseMove = useCallback(
  (e: MouseEvent) => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    const img = imageRef.current;
    if (!canvas || !ctx || !textractData) return;

    const pos = viewToNormalized(e);
    if (!pos) return;
    const { u, v } = pos;

    // 1) Always redraw base image + all highlights
    drawImageAndBlocks();

    const dpr = window.devicePixelRatio || 1;
    const { drawWidth, drawHeight, boxW, boxH, scale } = getDrawGeometry(
      img,
      rotation
    );
    const angleRad = (rotation * Math.PI) / 180;

    ctx.save();
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.translate(drawWidth / 2, drawHeight / 2);
    ctx.rotate(angleRad);

    if (isDrawingRef.current) {
      // 🔴 RUBBER BAND MODE
      const startU = startPosRef.current.x;
      const startV = startPosRef.current.y;

      const left = Math.min(startU, u);
      const top = Math.min(startV, v);
      const width = Math.abs(u - startU);
      const height = Math.abs(v - startV);

      const x = left * boxW - boxW / 2;
      const y = top * boxH - boxH / 2;
      const w = width * boxW;
      const h = height * boxH;

      ctx.beginPath();
      ctx.rect(x, y, w, h);
      ctx.strokeStyle = "red";
      ctx.lineWidth = 1 / scale;
      ctx.stroke();
      ctx.closePath();
    } else {
      // 🟢 HOVER MODE
      const hoverLine = textractData
        .listBlocks()
        .filter((block) => block.BlockType === "LINE")
        .find((line) => {
          const bb = line.Geometry?.BoundingBox;
          if (!bb) return false;
          const left = bb.Left;
          const top = bb.Top;
          const width = bb.Width;
          const height = bb.Height;
          return (
            u >= left &&
            u <= left + width &&
            v >= top &&
            v <= top + height
          );
        });

      if (hoverLine && hoverLine.Geometry?.BoundingBox) {
        const bb = hoverLine.Geometry.BoundingBox;

        const x = bb.Left * boxW - boxW / 2;
        const y = bb.Top * boxH - boxH / 2;
        const w = bb.Width * boxW;
        const h = bb.Height * boxH;

        ctx.beginPath();
        ctx.rect(x, y, w, h);
        ctx.strokeStyle = "green";
        ctx.lineWidth = 1 / scale;
        ctx.stroke();
        ctx.closePath();
      }
    }

    ctx.restore();
  },
  [drawImageAndBlocks, textractData, rotation, viewToNormalized]
);


  const handleMouseUp = useCallback(
    (e: MouseEvent) => {
      const canvas = canvasRef.current;
      const context = canvas?.getContext("2d");
      if (!canvas || !context || !isDrawingRef.current) return;

      const pos = viewToNormalized(e);
      if (!pos) return;

      const startX = startPosRef.current.x;
      const startY = startPosRef.current.y;
      const endX = pos.u;
      const endY = pos.v;

      const left = Math.min(startX, endX);
      const top = Math.min(startY, endY);
      const width = Math.abs(endX - startX);
      const height = Math.abs(endY - startY);

      if (width > 0 && height > 0) {
        onSelect(
          extractText({
            left,
            top,
            width,
            height,
          } as CustomBlock)
        );
      }

      isDrawingRef.current = false;
      isDrawingInProgressRef.current = false;

      // Redraw
      drawImageAndBlocks();
    },
    [drawImageAndBlocks, extractText, onSelect, viewToNormalized]
  );

  const handleMouseClick = useCallback(
    (e: MouseEvent) => {
      if (!textractData) return;
      const canvas = canvasRef.current;
      const context = canvas?.getContext("2d");
      if (!canvas || !context) return;

      const pos = viewToNormalized(e);
      if (!pos) return;
      const { u, v } = pos;

      const customLines = textractData
        .listBlocks()
        .filter((block) => block.BlockType === "LINE")
        .map((line) => {
          if (line.Geometry?.BoundingBox == null) return null;
          const { Left, Top, Width, Height } = line.Geometry.BoundingBox;
          return {
            left: Left,
            top: Top,
            width: Width,
            height: Height,
          } satisfies CustomBlock;
        })
        .filter((item) => item != null);

      customLines.some((line) => {
        const { left, top, width, height } = line as CustomBlock;
        const inside =
          u >= left &&
          u <= left + width &&
          v >= top &&
          v <= top + height;

        if (inside) {
          onSelect(
            extractText({
              left,
              top,
              width,
              height,
            } as CustomBlock)
          );
          return true;
        }
        return false;
      });
    },
    [textractData, extractText, onSelect, viewToNormalized]
  );

  // Set up image + listeners
  useEffect(() => {
    if (sources?.src?.length > 0 && "json" in sources) {
      const canvas = canvasRef.current;
      const image = imageRef.current;

      image.src = sources?.src[0];
      image.onload = () => {
        drawImageAndBlocks();
        popupWindow?.scrollTo(0, 0);
      };

      canvas?.addEventListener("click", handleMouseClick);
      canvas?.addEventListener("mousemove", handleMouseMove);
      canvas?.addEventListener("mousedown", handleMouseDown);
      canvas?.addEventListener("mouseup", handleMouseUp);

      const resizeHandler = () => {
        drawImageAndBlocks();
        popupWindow?.scrollTo(0, 0);
      };
      popupWindow?.addEventListener("resize", resizeHandler);
      const handler = () => {
        setRotation((prev) => (prev + 90) % 360);
      };
      popupWindow?.addEventListener("rotate-canvas", handler);

      return () => {
        canvas?.removeEventListener("click", handleMouseClick);
        canvas?.removeEventListener("mousemove", handleMouseMove);
        canvas?.removeEventListener("mousedown", handleMouseDown);
        canvas?.removeEventListener("mouseup", handleMouseUp);
        popupWindow?.removeEventListener("resize", resizeHandler);
        popupWindow?.removeEventListener("rotate-canvas", handler);
      };
    } else {
      const canvas = canvasRef.current;
      const context = canvas?.getContext("2d");
      if (canvas != null && context != null) {
        context.font = "bold 12px Arial";
        context.fillStyle = "red";
        context.fillText("Zoning data not available", 10, 10);
      }
    }
  }, [
    zoningSearch,
    activeField,
    sources,
    onSelect,
    extractText,
    handleMouseClick,
    handleMouseMove,
    handleMouseDown,
    handleMouseUp,
    drawImageAndBlocks,
    textractData,
    popupWindow,
  ]);

  // Highlight from localStorage "highlight"
  useEffect(() => {
    const messageHandler = () => {
      const highlightText = localStorage.getItem("highlight");
      if (highlightText) {
        setActiveField(highlightText);
      }
    };
    window.addEventListener("storage", messageHandler);

    return () => {
      window.removeEventListener("storage", messageHandler);
    };
  }, []);

  return <canvas ref={canvasRef} className="block m-auto" />;
}
