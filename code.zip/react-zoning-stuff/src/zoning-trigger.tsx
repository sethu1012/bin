import { useCallback, useEffect, useRef, useState } from "react";
import ZoningComponent, { CustomBlock } from "./zoning-canvas";

const ZoningTriggerComponent = ({
  sources,
  extractedTexts,
  onSelect,
  popupWindow,
  allDocuments,
}: {
  sources: { src: string[]; json: string[] };
  extractedTexts: string[];
  onSelect: ({ text, line }: { text: string; line: CustomBlock }) => void;
  popupWindow?: any;
  allDocuments?: Array<{
    index: number;
    imageUrl: string;
    jsonData: any;
  }>;
}) => {
  const [zoningSources, setZoningSources] = useState(sources);
  const [zoningExtractedTexts, setZoningExtractedTexts] =
    useState(extractedTexts);
  const [zoningSearch, setZoningSearch] = useState<string>("");
  const [searchString, setSearchString] = useState<string>("");
  const [errorMessage, setErrorMessage] = useState<boolean>(false);
  const [errorText, setErrorText] = useState<string>("");
  const [currentIndex, setCurrentIndex] = useState(0);

  // Track allDocuments in a ref to avoid stale closures
  const allDocumentsRef = useRef(allDocuments);
  useEffect(() => {
    allDocumentsRef.current = allDocuments;
  }, [allDocuments]);

  // Handle document navigation
  const handleDocumentChange = useCallback((index: number) => {
    const docs = allDocumentsRef.current;
    if (!docs || docs.length === 0) return;

    const doc = docs[index];
    if (!doc) return;

    console.info("Switching to document:", index);
    setCurrentIndex(index);

    // Update sources with the new document
    setZoningSources({
      src: [doc.imageUrl],
      json: doc.jsonData,
    });

    // Notify popup window to update pagination buttons
    if (popupWindow && typeof popupWindow.updatePagination === "function") {
      popupWindow.updatePagination(index);
    }
  }, [popupWindow]);

  // Handle navigation events from popup window
  const handleFirst = () => handleDocumentChange(0);
  const handlePrev = () => handleDocumentChange(Math.max(0, currentIndex - 1));
  const handleNext = () => {
    const docs = allDocumentsRef.current;
    const maxIndex = docs ? docs.length - 1 : 0;
    handleDocumentChange(Math.min(maxIndex, currentIndex + 1));
  };
  const handleLast = () => {
    const docs = allDocumentsRef.current;
    const maxIndex = docs ? docs.length - 1 : 0;
    handleDocumentChange(maxIndex);
  };

  useEffect(() => {
    const win = window;
    const handleMessage = (event: MessageEvent) => {
      if (event?.data?.type === "updateData") {
        setZoningSearch("");
        setZoningSources(event.data.sources);
        setZoningExtractedTexts(event.data.extractedTexts);
      }
    };

    const handleWheel = (event: WheelEvent) => {
      if (event.ctrlKey) {
        event.preventDefault();
      }
    };

    win.addEventListener("message", handleMessage);
    win.addEventListener("wheel", handleWheel, { passive: false });

    // Register pagination event listeners on popup window
    if (popupWindow) {
      popupWindow.addEventListener("first-doc", handleFirst);
      popupWindow.addEventListener("prev-doc", handlePrev);
      popupWindow.addEventListener("next-doc", handleNext);
      popupWindow.addEventListener("last-doc", handleLast);

      return () => {
        win.removeEventListener("message", handleMessage);
        win.removeEventListener("wheel", handleWheel);
        popupWindow.removeEventListener("first-doc", handleFirst);
        popupWindow.removeEventListener("prev-doc", handlePrev);
        popupWindow.removeEventListener("next-doc", handleNext);
        popupWindow.removeEventListener("last-doc", handleLast);
      };
    }

    return () => {
      win.removeEventListener("message", handleMessage);
      win.removeEventListener("wheel", handleWheel);
    };
  }, [popupWindow, handleFirst, handlePrev, handleNext, handleLast, currentIndex]);

  // When allDocuments changes, update the popup's allDocuments reference
  useEffect(() => {
    if (popupWindow && allDocuments && allDocuments.length > 0) {
      // Update the popup's allDocuments array
      (popupWindow as any).allDocuments = allDocuments;
      (popupWindow as any).totalDocs = allDocuments.length;

      // Update pagination if there's a function to do so
      if (typeof popupWindow.updatePagination === "function") {
        popupWindow.updatePagination(currentIndex);
      }
    }
  }, [allDocuments, popupWindow, currentIndex]);

  return (
    <div className="h-full flex flex-col gap-2 overflow-hidden">
      <div className="flex-1 overflow-auto">
        <ZoningComponent
          onSelect={onSelect}
          extractedTexts={zoningExtractedTexts}
          sources={{
            src: zoningSources.src,
            json: zoningSources.json,
          }}
          zoningSearch={zoningSearch}
          popupWindow={popupWindow}
        />
      </div>
      {sources?.src && sources?.json && (
        <>
          <div
            className="flex gap-2 p-2"
            style={{ margin: "10px", display: "flex", gap: "5px" }}
          >
            <input
              value={searchString}
              onChange={(e) => setSearchString(e.target.value)}
              type="text"
              placeholder="Search..."
              autoFocus
              className="flex-grow border border-gray-300 rounded p-2"
            />

            {/* <button className="p-2" onClick={() => setZoningSearch(searchString)}> */}
            <button
              className="p-2"
              onClick={() => {
                if (searchString === "") {
                  setErrorMessage(true);
                  setErrorText("Enter Text.");
                } else {
                  setZoningSearch(searchString);
                  setErrorMessage(false);
                  setErrorText("");
                }
              }}
            >
              Search
            </button>
            <button
              className="p-2"
              onClick={() => {
                setZoningSearch("");
                setSearchString("");
              }}
              disabled={!searchString}
            >
              Clear
            </button>

            {errorMessage && (
              <p
                style={{
                  color: "Crimson",
                  marginTop: "10px",
                  fontWeight: "bold",
                }}
              >
                {errorText}
              </p>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default ZoningTriggerComponent;
