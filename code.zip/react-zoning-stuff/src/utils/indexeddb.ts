const DB_NAME = "ZoningDocumentsDB";
const DB_VERSION = 1;
const STORE_NAME = "documents";

export async function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: "key" });
        store.createIndex("taskId", "taskId", { unique: false });
        store.createIndex("createdAt", "createdAt", { unique: false });
      }
    };
  });
}

export async function saveDocument(
  taskId: string,
  index: number,
  imageBlob: Blob,
  jsonData: any
): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(STORE_NAME, "readwrite");
  const store = tx.objectStore(STORE_NAME);

  return new Promise((resolve, reject) => {
    const request = store.put({
      key: `${taskId}-${index}`,
      taskId,
      index,
      imageBlob,
      jsonData,
      createdAt: Date.now(),
    });

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function getDocument(
  taskId: string,
  index: number
): Promise<{ imageBlob: Blob; jsonData: any } | null> {
  const db = await openDB();
  return new Promise((resolve) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const request = store.get(`${taskId}-${index}`);

    request.onsuccess = () => {
      const result = request.result;
      if (result) {
        resolve({
          imageBlob: result.imageBlob,
          jsonData: result.jsonData,
        });
      } else {
        resolve(null);
      }
    };
    request.onerror = () => resolve(null);
  });
}

export async function getAllDocuments(
  taskId: string
): Promise<Array<{ index: number; imageUrl: string; jsonData: any }>> {
  const db = await openDB();
  return new Promise((resolve) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const index = store.index("taskId");
    const request = index.getAll(taskId);

    request.onsuccess = () => {
      const results = request.result || [];
      // Convert blobs to blob URLs
      resolve(
        results
          .sort((a: any, b: any) => a.index - b.index)
          .map((r: any) => ({
            index: r.index,
            imageUrl: URL.createObjectURL(r.imageBlob),
            jsonData: r.jsonData,
          }))
      );
    };
    request.onerror = () => resolve([]);
  });
}

// Clear all documents for a specific task (when task changes)
export async function clearTaskCache(taskId: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const index = store.index("taskId");
    const request = index.openCursor(IDBKeyRange.only(taskId));

    request.onsuccess = (event) => {
      const cursor = (event.target as IDBRequest).result;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      } else {
        resolve();
      }
    };
    request.onerror = () => resolve();
  });
}

// Optional: Clear all expired entries (for cleanup, run on mount)
export async function clearOldCache(
  maxAge = 7 * 24 * 60 * 60 * 1000
): Promise<void> {
  const db = await openDB();
  return new Promise((resolve) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const index = store.index("createdAt");
    const cutoff = Date.now() - maxAge;

    const request = index.openCursor(IDBKeyRange.upperBound(cutoff));

    request.onsuccess = (event) => {
      const cursor = (event.target as IDBRequest).result;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      } else {
        resolve();
      }
    };
    request.onerror = () => resolve();
  });
}
