# Zoning Document Pagination Feature - Changes Summary

## Overview
Added pagination support for 30-70 zoning documents with Next/Prev buttons, background prefetch, and IndexedDB caching.

---

## File: `src/utils/indexeddb.ts` (NEW)

### What It Does
Stores zoning documents (images + data) in browser IndexedDB for persistent caching.

### Functions Added

| Function | Description |
|----------|-------------|
| `openDB()` | Opens/creates IndexedDB database `ZoningDocumentsDB` |
| `saveDocument(taskId, index, imageBlob, jsonData)` | Saves a document with blob + JSON to cache |
| `getDocument(taskId, index)` | Retrieves a single document from cache |
| `getAllDocuments(taskId)` | Gets all documents for a task (returns blob URLs) |
| `clearTaskCache(taskId)` | Clears cache when task changes |
| `clearOldCache(maxAge)` | Cleans up entries older than 7 days |

### DB Schema
- Database: `ZoningDocumentsDB` (v1)
- Store: `documents`
- Indexes: `taskId`, `createdAt`

---

## File: `src/use-agent.tsx`

### Imports Added
```typescript
import { useRef } from "react";
import {
  getAllDocuments,
  saveDocument,
  clearTaskCache,
  clearOldCache,
} from "~/utils/indexeddb";
```

### State Added
```typescript
const prevTaskIdRef = useRef<string | null>(null);
```

### Helper Function Added: `fetchRemainingDocuments()`
```typescript
const fetchRemainingDocuments = useCallback(
  async (taskId: string, zoningDocs: any, startIndex: number) => {
    // Fetches remaining documents in background
    // Saves to IndexedDB
    // Updates context with newly fetched documents
  },
  []
);
```

### `fetchData()` Function Changes

**Old behavior:** Fetches only `zoningDocs.imageurl[0]`

**New behavior:**
1. Check if task changed → clear previous task's cache
2. Check IndexedDB cache first
3. If cache hit → use first doc immediately, fetch rest in background
4. If cache miss → fetch first doc (await), fetch rest in background
5. Save all documents to IndexedDB

**New data structure:**
```typescript
zoningdocuments: {
  currentDocument: { imageUrl: blobUrl, jsonData },
  allDocuments: [{ index, imageUrl, jsonData }, ...],
  totalCount: number,
  fromCache: boolean
}
```

### Cleanup Effects Updated

**Old:** Only revoked single blob URL
```typescript
if (data?.zoningdocuments?.imageurl?.[0]?.startsWith("blob:")) {
  URL.revokeObjectURL(data.zoningdocuments.imageurl[0]);
}
```

**New:** Revokes all blob URLs from `allDocuments` array
```typescript
data?.zoningdocuments?.allDocuments?.forEach((doc: any) => {
  if (doc?.imageUrl?.startsWith("blob:")) {
    URL.revokeObjectURL(doc.imageUrl);
  }
});
```

### New Effect: Old Cache Cleanup
```typescript
useEffect(() => {
  clearOldCache().catch((err) =>
    console.warn("Failed to clear old cache:", err)
  );
}, []);
```

---

## File: `src/popover.tsx`

### Interface Updated

```typescript
export interface IPopoverProps {
  // ... existing props ...
  // NEW: Pagination props
  allDocuments?: Array<{
    index: number;
    imageUrl: string; // blob URL
    jsonData: any;
  }>;
}
```

### Component Updated

```typescript
const Popover = ({
  // ... existing props ...
  allDocuments, // NEW
}: IPopoverProps) => {
```

### CSS Styles Added (zoning section)

```css
.pagination-controls {
  display: flex;
  align-items: center;
  gap: 5px;
}
.nav-btn {
  padding: 5px 10px;
  border-radius: 6px;
  border: 1px solid #ccc;
  background: #ffffff;
  cursor: pointer;
  font-size: 12px;
}
.nav-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
.doc-indicator {
  font-size: 12px;
  font-weight: 600;
  margin: 0 5px;
}
```

### HTML Added (zoning popup - button-container)

```html
<div class="pagination-controls">
  <button id="first-btn" class="nav-btn">&laquo; First</button>
  <button id="prev-btn" class="nav-btn">&lsaquo; Prev</button>
  <span id="doc-indicator" class="doc-indicator">1 / 1</span>
  <button id="next-btn" class="nav-btn">Next &rsaquo;</button>
  <button id="last-btn" class="nav-btn">Last &raquo;</button>
</div>
```

### JavaScript Added (zoning popup - window.onload)

```javascript
// Pagination setup
const totalDocs = window.allDocuments?.length || 1;
let currentIndex = 0;

const firstBtn = document.getElementById("first-btn");
const prevBtn = document.getElementById("prev-btn");
const nextBtn = document.getElementById("next-btn");
const lastBtn = document.getElementById("last-btn");
const indicator = document.getElementById("doc-indicator");

function updatePagination() {
  firstBtn.disabled = currentIndex === 0;
  prevBtn.disabled = currentIndex === 0;
  nextBtn.disabled = currentIndex === totalDocs - 1;
  lastBtn.disabled = currentIndex === totalDocs - 1;
  indicator.textContent = currentIndex + 1 + " / " + totalDocs;
}

function showDocument(index) {
  const doc = window.allDocuments[index];
  if (!doc) return;
  currentIndex = index;
  updatePagination();
  // Trigger document change event for parent to handle
  if (window.opener && !window.opener.closed) {
    window.opener.postMessage({
      type: "zoningPageChange",
      index: index,
    }, "*");
  }
}

// Event listeners
if (firstBtn) firstBtn.addEventListener("click", () => showDocument(0));
if (prevBtn) prevBtn.addEventListener("click", () => showDocument(Math.max(0, currentIndex - 1)));
if (nextBtn) nextBtn.addEventListener("click", () => showDocument(Math.min(totalDocs - 1, currentIndex + 1)));
if (lastBtn) lastBtn.addEventListener("click", () => showDocument(totalDocs - 1));

// Initialize
updatePagination();
```

### Script Tag Added (pass allDocuments to popup)

```html
<script>
  window.allDocuments = ${JSON.stringify(allDocuments || [])};
  window.totalDocs = ${allDocuments?.length || 1};
</script>
```

### Props Passed to ZoningTriggerComponent

```typescript
<ZoningTriggerComponent
  // ... existing props ...
  allDocuments={allDocuments} // NEW
/>
```

---

## File: `src/zoning-trigger.tsx`

### Imports Updated

```typescript
import { useCallback, useEffect, useRef, useState } from "react";
```

### Props Added

```typescript
allDocuments?: Array<{
  index: number;
  imageUrl: string;
  jsonData: any;
}>;
```

### State Added

```typescript
const [currentIndex, setCurrentIndex] = useState(0);
const allDocumentsRef = useRef(allDocuments);
```

### Helper Function Added: `handleDocumentChange()`

```typescript
const handleDocumentChange = useCallback((index: number) => {
  const docs = allDocumentsRef.current;
  if (!docs || docs.length === 0) return;

  const doc = docs[index];
  if (!doc) return;

  console.info("Switching to document:", index);
  setCurrentIndex(index);

  // Update sources with the new document
  setZoningSources({
    src: [doc.imageUrl],
    json: doc.jsonData,
  });

  // Notify popup window to update pagination buttons
  if (popupWindow && typeof popupWindow.updatePagination === "function") {
    popupWindow.updatePagination(index);
  }
}, [popupWindow]);
```

### Navigation Handlers Added

```typescript
const handleFirst = () => handleDocumentChange(0);
const handlePrev = () => handleDocumentChange(Math.max(0, currentIndex - 1));
const handleNext = () => {
  const docs = allDocumentsRef.current;
  const maxIndex = docs ? docs.length - 1 : 0;
  handleDocumentChange(Math.min(maxIndex, currentIndex + 1));
};
const handleLast = () => {
  const docs = allDocumentsRef.current;
  const maxIndex = docs ? docs.length - 1 : 0;
  handleDocumentChange(maxIndex);
};
```

### useEffect Updated - Event Listeners Added

```typescript
// Register pagination event listeners on popup window
if (popupWindow) {
  popupWindow.addEventListener("first-doc", handleFirst);
  popupWindow.addEventListener("prev-doc", handlePrev);
  popupWindow.addEventListener("next-doc", handleNext);
  popupWindow.addEventListener("last-doc", handleLast);

  return () => {
    // ... cleanup
    popupWindow.removeEventListener("first-doc", handleFirst);
    popupWindow.removeEventListener("prev-doc", handlePrev);
    popupWindow.removeEventListener("next-doc", handleNext);
    popupWindow.removeEventListener("last-doc", handleLast);
  };
}
```

### New useEffect: Update Popup Documents

```typescript
useEffect(() => {
  if (popupWindow && allDocuments && allDocuments.length > 0) {
    (popupWindow as any).allDocuments = allDocuments;
    (popupWindow as any).totalDocs = allDocuments.length;

    if (typeof popupWindow.updatePagination === "function") {
      popupWindow.updatePagination(currentIndex);
    }
  }
}, [allDocuments, popupWindow, currentIndex]);
```

---

## File: `src/index.tsx`

### Popover Props Updated

```typescript
<Popover
  type={popupType}
  document={document}
  extractedTexts={extractedTexts}
  sources={sources}
  onSelect={handleSelect}
  allDocuments={data?.zoningdocuments?.allDocuments} // NEW
  key={taskId}
/>
```

### `sources` useMemo Updated

**Old:**
```typescript
const sources = useMemo(() => {
  return {
    src: data?.zoningdocuments?.imageurl,
    json: data?.zoningdocuments?.jsonurl,
    jsonData: data?.zoningdocuments?.jsonData,
  };
}, [data?.zoningdocuments]);
```

**New:**
```typescript
const sources = useMemo(() => {
  const zoning = data?.zoningdocuments;
  if (!zoning) {
    return { src: undefined, json: undefined, jsonData: undefined };
  }

  // Use new structure if available, fallback to legacy
  return {
    src: zoning.currentDocument?.imageUrl || zoning.imageurl,
    json: zoning.jsonurl,
    jsonData: zoning.currentDocument?.jsonData || zoning.jsonData,
  };
}, [data?.zoningdocuments]);
```

### postMessage Handler Updated

```typescript
// Handle zoning page change from popup
if (event.data?.type === "zoningPageChange") {
  const { index } = event.data;
  const doc = data?.zoningdocuments?.allDocuments?.[index];
  if (doc) {
    console.info("Navigating to document:", index);
    // ZoningTriggerComponent handles the actual document change via events
  }
}
```

---

## File: `src/zoning.tsx`

### No Changes Required

This file already uses `sources.src[0]` to get the image URL. When `zoningSources` is updated with a new document, it automatically picks up the new image.

---

## Data Flow Diagram

```
┌─────────────────┐
│  use-agent.tsx  │
│  (fetchData)    │
└────────┬────────┘
         │
         ├─→ Check IndexedDB cache
         │   └─→ Hit? Use first doc, fetch rest in background
         │   └─→ Miss? Fetch first doc (await), fetch rest in background
         │
         ├─→ Save to IndexedDB
         │
         └─→ Set context data:
             zoningdocuments: {
               currentDocument: { imageUrl, jsonData },
               allDocuments: [{ index, imageUrl, jsonData }, ...],
               totalCount: N
             }

┌─────────────────┐
│   index.tsx     │
└────────┬────────┘
         │
         └─→ Pass allDocuments to Popover

┌─────────────────┐
│  popover.tsx    │
│  (zoning mode)  │
└────────┬────────┘
         │
         ├─→ Write popup HTML with pagination buttons
         │
         ├─→ Pass allDocuments via window.allDocuments
         │
         └─→ Pass allDocuments to ZoningTriggerComponent

┌─────────────────────────┐
│  zoning-trigger.tsx     │
└────────┬────────────────┘
         │
         ├─→ Listen for first-doc/prev-doc/next-doc/last-doc events
         │
         └─→ Update zoningSources with new document

┌─────────────────┐
│   zoning.tsx    │
└────────┬────────┘
         │
         └─→ Uses sources.src[0] → automatically shows new image
```

---

## Testing Checklist

- [ ] Single document works (no pagination if only 1)
- [ ] 30-70 documents show pagination buttons
- [ ] First/Prev/Next/Last buttons navigate correctly
- [ ] Buttons disabled at boundaries
- [ ] Document indicator shows correct position (e.g., "1 / 30")
- [ ] First document appears quickly
- [ ] Background downloads complete silently
- [ ] IndexedDB persists across page refresh
- [ ] Check IndexedDB in DevTools (Application > IndexedDB)
- [ ] Task change clears previous cache
- [ ] Blob URLs properly cleaned up
- [ ] Network throttling - first doc still appears quickly

---

## Files Modified Summary

| File | Type | Lines Added | Purpose |
|------|------|-------------|---------|
| `src/utils/indexeddb.ts` | NEW | ~120 | IndexedDB helper functions |
| `src/use-agent.tsx` | MODIFIED | ~80 | Cache-first fetch, background download |
| `src/popover.tsx` | MODIFIED | ~60 | Pagination UI + button handlers |
| `src/zoning-trigger.tsx` | MODIFIED | ~60 | Navigation event handlers |
| `src/index.tsx` | MODIFIED | ~15 | Pass allDocuments, handle postMessage |
| `src/zoning.tsx` | NO CHANGE | 0 | Already compatible |
