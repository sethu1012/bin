# Zoning Document Pagination Feature - Changes by Component

## Overview
Added pagination support for 30-70 zoning documents with Next/Prev buttons, background prefetch, and IndexedDB caching.

---

## Component 1: IndexedDB Helper Utility

**Location:** `stuff.tsx` lines 1-204

### What It Does
Stores zoning documents (images + data) in browser IndexedDB for persistent caching.

### Changes Made

**Step 1: Add database constants**
```typescript
const ZONING_DB_NAME = "ZoningDocumentsDB";
const ZONING_STORE_NAME = "documents";
const ZONING_DB_VERSION = 1;
```

**Step 2: Define types**
```typescript
type ZoningDocument = {
  id: string;
  index: number;
  imageUrl: string;
  imageBlob: Blob;
  jsonData: any;
  createdAt: number;
};

type CachedZoningData = {
  id: string;
  documents: ZoningDocument[];
  totalCount: number;
  createdAt: number;
  expiresAt: number;
};
```

**Step 3: Add `openZoningDB()` function**
- Opens/creates IndexedDB database
- Creates object store with `expiresAt` index

**Step 4: Add `saveZoningDocumentsToCache()` function**
- Saves documents with blobs to IndexedDB
- Includes TTL (24 hours default)

**Step 5: Add `getZoningDocumentsFromCache()` function**
- Retrieves cached documents
- Returns null if expired or not found

**Step 6: Add `deleteZoningDocumentsCache()` function**
- Deletes specific cache entry by key

**Step 7: Add `clearExpiredZoningCache()` function**
- Removes all expired entries from database

**Step 8: Add `cachedDocumentsToBlobUrls()` function**
- Converts cached blobs back to blob URLs for use

---

## Component 2: IPopoverProps Interface

**Location:** `stuff.tsx` lines 206-229

### What It Does
TypeScript interface defining props for the Popover component.

### Changes Made

**Step 1: Add pagination props to interface**
```typescript
export interface IPopoverProps {
  // ... existing props ...

  // NEW: Pagination props (only allDocuments needed)
  allDocuments?: Array<{
    imageUrl: string;      // blob URL
    jsonData: any;         // parsed Textract JSON
    presignedUrl: string;  // original S3 URL
    index: number;
  }>;
}
```

**Note:** No `currentDocumentIndex` or `onPageChange` props needed - uses postMessage instead.

---

## Component 3: Popover (Zoning Mode)

**Location:** `stuff.tsx` lines 231-439

### What It Does
Opens popup window with zoning document viewer and pagination controls.

### Changes Made

**Step 1: Destructure new prop from function arguments**
```typescript
const Popover = ({
  type = "zoning",
  document,
  sources,
  extractedTexts,
  onSelect,
  allDocuments,  // NEW
}: IPopoverProps) => {
```

**Step 2: Calculate total documents and default index**
```typescript
if (type === "zoning") {
  const totalDocs = allDocuments?.length || 1;
  const currentIndex = 0;  // Default to index 0
```

**Step 3: Pass documents to popup window via JavaScript**
```javascript
window.allDocuments = ${JSON.stringify(allDocuments || [])};
window.currentDocumentIndex = ${currentIndex};
window.totalDocs = ${totalDocs};
```

**Step 4: Add 4 navigation buttons to HTML**
```html
<div class="button-left">
  <button id="first-btn" class="nav-button">&laquo; First</button>
  <button id="prev-btn" class="nav-button">&lsaquo; Prev</button>
  <span id="doc-indicator" class="doc-indicator">Document 1 of X</span>
  <button id="next-btn" class="nav-button">Next &rsaquo;</button>
  <button id="last-btn" class="nav-button">Last &raquo;</button>
</div>
```

**Step 5: Add button click handlers**
```javascript
firstBtn.addEventListener("click", () => {
  window.dispatchEvent(new CustomEvent("first-doc"));
});

prevBtn.addEventListener("click", () => {
  window.dispatchEvent(new CustomEvent("prev-doc"));
});

nextBtn.addEventListener("click", () => {
  window.dispatchEvent(new CustomEvent("next-doc"));
});

lastBtn.addEventListener("click", () => {
  window.dispatchEvent(new CustomEvent("last-doc"));
});
```

**Step 6: Add button state management**
```javascript
function updatePaginationButtons() {
  firstBtn.disabled = window.currentDocumentIndex === 0;
  prevBtn.disabled = window.currentDocumentIndex === 0;
  nextBtn.disabled = window.currentDocumentIndex === window.totalDocs - 1;
  lastBtn.disabled = window.currentDocumentIndex === window.totalDocs - 1;
  indicator.textContent = "Document " + (window.currentDocumentIndex + 1) + " of " + window.totalDocs;
}

window.updatePagination = function(index) {
  window.currentDocumentIndex = index;
  updatePaginationButtons();
};
```

**Step 7: Add CSS styles for pagination buttons**
```css
.button-left { display: flex; align-items: center; gap: 5px; }
.doc-indicator { font-size: 12px; font-weight: 600; margin: 0 5px; }
.nav-button:disabled { opacity: 0.5; cursor: not-allowed; }
```

**Step 8: Pass `allDocuments` to ZoningTriggerComponent**
```typescript
<ZoningTriggerComponent
  // ... existing props ...
  allDocuments={allDocuments}  // NEW
/>
```

**Step 9: Add `allDocuments` to useEffect dependencies**
```typescript
}, [document, extractedTexts, onSelect, sources, type, allDocuments]);
```

---

## Component 4: ZoningTriggerComponent

**Location:** `stuff.tsx` lines 1076-1274

### What It Does
Wrapper around ZoningComponent with search UI and pagination logic.

### Changes Made

**Step 1: Add new imports**
```typescript
import { useCallback } from "react";  // NEW
import { http } from "~/services/api.services";  // NEW
import { getGenericURL } from "~/utils/basic";  // NEW
```

**Step 2: Add DocumentCache type**
```typescript
type DocumentCache = Map<number, { imageUrl: string; jsonData: any }>;
```

**Step 3: Remove currentDocumentIndex and onPageChange from props**
```typescript
const ZoningTriggerComponent = ({
  sources,
  extractedTexts,
  onSelect,
  popupWindow,
  allDocuments,  // Keep this
  // REMOVED: currentDocumentIndex, onPageChange
}: {
  // ... existing prop types ...
  allDocuments?: Array<{...}>;
  // REMOVED: currentDocumentIndex?: number, onPageChange?: (index: number) => void
}) => {
```

**Step 4: Add pagination state**
```typescript
const [currentIndex, setCurrentIndex] = useState(0);  // Default to 0
const [documentCache, setDocumentCache] = useState<DocumentCache>(new Map());
const prefetchCacheRef = useRef<Set<number>>(new Set());
```

**Step 5: Add `prefetchBackground()` function**
```typescript
const prefetchBackground = useCallback(async (index: number) => {
  if (documentCache.has(index) || prefetchCacheRef.current.has(index)) return;

  prefetchCacheRef.current.add(index);

  const [imageResponse, jsonResponse] = await Promise.all([
    http.get(getGenericURL(doc.presignedUrl)),
    http.get(getGenericURL(doc.jsonData)),
  ]);

  const imageBlob = await imageResponse.blob();
  const imageUrl = URL.createObjectURL(imageBlob);
  const jsonData = await jsonResponse.json();

  setDocumentCache(prev => new Map(prev).set(index, { imageUrl, jsonData }));
}, [allDocuments, documentCache]);
```

**Step 6: Add prefetch effect (with large jump support)**
```typescript
useEffect(() => {
  if (!allDocuments || allDocuments.length <= 1) return;

  // Prefetch current document if not in cache
  if (!documentCache.has(currentIndex)) {
    prefetchBackground(currentIndex);
  }

  // Prefetch previous if not first
  if (currentIndex > 0) {
    prefetchBackground(currentIndex - 1);
  }

  // Prefetch next if not last
  if (currentIndex < allDocuments.length - 1) {
    prefetchBackground(currentIndex + 1);
  }

  // Additional prefetch for large jumps - prefetch nearby range
  const prefetchRange = 2; // Prefetch 2 documents in each direction
  for (let i = 1; i <= prefetchRange; i++) {
    if (currentIndex - i >= 0 && !documentCache.has(currentIndex - i)) {
      prefetchBackground(currentIndex - i);
    }
    if (currentIndex + i < allDocuments.length && !documentCache.has(currentIndex + i)) {
      prefetchBackground(currentIndex + i);
    }
  }
}, [currentIndex, allDocuments, prefetchBackground, documentCache]);
```

**Step 7: Add navigation handlers (with First/Last)**
```typescript
const handleFirst = () => {
  if (!allDocuments || allDocuments.length === 0) return;
  const newIndex = 0;
  setCurrentIndex(newIndex);
  popupWindow?.updatePagination(newIndex);

  if (window.opener && !window.opener.closed) {
    window.opener.postMessage({
      type: "zoningPageChange",
      index: newIndex,
    }, "*");
  }
};

const handlePrev = () => {
  if (!allDocuments || currentIndex <= 0) return;
  const newIndex = currentIndex - 1;
  setCurrentIndex(newIndex);
  popupWindow?.updatePagination(newIndex);

  if (window.opener && !window.opener.closed) {
    window.opener.postMessage({
      type: "zoningPageChange",
      index: newIndex,
    }, "*");
  }
};

const handleNext = () => {
  if (!allDocuments || currentIndex >= allDocuments.length - 1) return;
  const newIndex = currentIndex + 1;
  setCurrentIndex(newIndex);
  popupWindow?.updatePagination(newIndex);

  if (window.opener && !window.opener.closed) {
    window.opener.postMessage({
      type: "zoningPageChange",
      index: newIndex,
    }, "*");
  }
};

const handleLast = () => {
  if (!allDocuments || allDocuments.length === 0) return;
  const newIndex = allDocuments.length - 1;
  setCurrentIndex(newIndex);
  popupWindow?.updatePagination(newIndex);

  if (window.opener && !window.opener.closed) {
    window.opener.postMessage({
      type: "zoningPageChange",
      index: newIndex,
    }, "*");
  }
};
```

**Step 8: Add effect to update sources when currentIndex changes**
```typescript
useEffect(() => {
  const cachedDoc = documentCache.get(currentIndex);
  const doc = allDocuments[currentIndex];

  if (cachedDoc) {
    setZoningSources({ src: [cachedDoc.imageUrl], json: cachedDoc.jsonData });
  } else if (doc) {
    setZoningSources({ src: [doc.imageUrl], json: doc.jsonData });
  }
}, [currentIndex, allDocuments, documentCache]);
```

**Step 9: Add cleanup effect for blob URLs**
```typescript
useEffect(() => {
  return () => {
    documentCache.forEach((doc) => {
      if (doc.imageUrl?.startsWith("blob:")) {
        URL.revokeObjectURL(doc.imageUrl);
      }
    });
  };
}, [documentCache]);
```

**Step 10: Update useEffect dependencies**
```typescript
// Register all 4 event listeners
if (popupWindow) {
  popupWindow.addEventListener("first-doc", handleFirst);
  popupWindow.addEventListener("prev-doc", handlePrev);
  popupWindow.addEventListener("next-doc", handleNext);
  popupWindow.addEventListener("last-doc", handleLast);

  return () => {
    popupWindow.removeEventListener("first-doc", handleFirst);
    popupWindow.removeEventListener("prev-doc", handlePrev);
    popupWindow.removeEventListener("next-doc", handleNext);
    popupWindow.removeEventListener("last-doc", handleLast);
  };
}
}, [currentIndex, allDocuments, popupWindow]);
```

---

## Component 5: AgentStateProvider

**Location:** `stuff.tsx` lines 1952-2266

### What It Does
React Context provider that fetches and manages agent data including zoning documents.

### Changes Made

**Step 1: Add `useRef` to imports**
```typescript
import { ..., useRef } from "react";
```

**Step 2: Add ref to track previous task ID**
```typescript
const prevTaskIdRef = useRef<string | null>(null);
```

**Step 3: Modify fetchData to clear old cache on task change**
```typescript
const taskId = (mainData as any)?.data?.taskid;

// NEW: Clear old cache when task changes
if (prevTaskIdRef.current && prevTaskIdRef.current !== taskId) {
  const oldCacheKey = `zoning-${roleid}-${prevTaskIdRef.current}`;
  console.info("Task changed, clearing old cache:", oldCacheKey);
  deleteZoningDocumentsCache(oldCacheKey);
}
prevTaskIdRef.current = taskId;

const cacheKey = `zoning-${roleid}-${taskId}`;
```

**Step 4: Add IndexedDB cache check before fetching**
```typescript
// NEW: CHECK CACHE FIRST
const cachedData = await getZoningDocumentsFromCache(cacheKey);

if (cachedData && cachedData.totalCount === zoningDocs.imageurl.length) {
  console.info("Using cached zoning documents:", cachedData.totalCount, "documents");

  const blobDocs = cachedDocumentsToBlobUrls(cachedData.documents);

  const enrichedData = {
    ...(mainData as any)?.data,
    zoningdocuments: {
      ...zoningDocs,
      originalImageUrls: zoningDocs.imageurl,
      originalJsonUrls: zoningDocs.jsonurl,
      allDocuments: blobDocs,
      imageurl: [blobDocs[0].imageUrl],
      jsonData: blobDocs[0].jsonData,
      _fromCache: true,
    },
  };

  setData(enrichedData);
  setFormStatus("VALID");
  // ... agentKeyedOn code ...
  return;  // Early return on cache hit
}

console.info("Cache miss - fetching zoning documents from API...");
```

**Step 5: Change to fetch ALL documents (not just index 0)**
```typescript
// OLD: zoningDocs.imageurl[0]
// NEW: zoningDocs.imageurl.map(...) - fetch ALL

const allDocsPromises = zoningDocs.imageurl.map(async (imageUrl, index) => {
  const [imageResponse, jsonResponse] = await Promise.all([
    http.get(getGenericURL(imageUrl)),
    http.get(getGenericURL(zoningDocs.jsonurl[index])),
  ]);

  const imageBlob = await imageResponse.blob();
  const blobUrl = URL.createObjectURL(imageBlob);
  const jsonData = await jsonResponse.json();

  return {
    imageUrl: blobUrl,
    jsonData,
    presignedUrl: imageUrl,
    index,
    imageBlob,  // Keep for caching
  };
});
```

**Step 6: Update data structure with allDocuments**
```typescript
const enrichedData = {
  ...(mainData as any)?.data,
  zoningdocuments: {
    ...zoningDocs,
    originalImageUrls: zoningDocs.imageurl,
    originalJsonUrls: zoningDocs.jsonurl,
    allDocuments: validDocs.map(({ imageBlob, ...rest }) => rest),  // All documents
    imageurl: [validDocs[0].imageUrl],  // First doc (backward compat)
    jsonData: validDocs[0].jsonData,
    _fromCache: false,
  },
};
```

**Step 7: Add async cache save after fetch**
```typescript
// NEW: SAVE TO CACHE (async, don't await)
saveZoningDocumentsToCache(
  cacheKey,
  validDocs.map((doc) => ({
    imageUrl: doc.presignedUrl,
    imageBlob: doc.imageBlob,
    jsonData: doc.jsonData,
    index: doc.index,
  })),
  24 * 60 * 60 * 1000,  // 24 hours TTL
).then(() => console.info("Zoning documents cached successfully"));
```

**Step 8: Enhance cleanup effect for all blob URLs**
```typescript
useEffect(() => {
  return () => {
    // NEW: Revoke all blob URLs from allDocuments
    data?.zoningdocuments?.allDocuments?.forEach((doc) => {
      if (doc?.imageUrl?.startsWith("blob:")) {
        URL.revokeObjectURL(doc.imageUrl);
      }
    });

    // Existing: revoke from legacy format
    if (data?.zoningdocuments?.imageurl?.[0]?.startsWith("blob:")) {
      URL.revokeObjectURL(data.zoningdocuments.imageurl[0]);
    }
  };
}, [data]);
```

**Step 9: Add cache cleanup on mount**
```typescript
useEffect(() => {
  clearExpiredZoningCache().catch((err) =>
    console.warn("Failed to clear expired cache:", err)
  );
}, []);
```

---

## Parent Component

### Changes Required: **NONE**

The parent component does NOT need to track state. Popover uses `postMessage` to communicate.

### Optional: Listen for page changes

**Step 1: Add message listener** (if you want to know when page changes)
```typescript
useEffect(() => {
  const handleMessage = (event: MessageEvent) => {
    if (event.data?.type === "zoningPageChange") {
      const { index } = event.data;
      console.log("User navigated to document:", index);
      // Do something with the new index
    }
  };

  window.addEventListener("message", handleMessage);
  return () => window.removeEventListener("message", handleMessage);
}, []);
```

---

## Summary of Changes by Component

| Component | Lines Changed | What Was Added |
|-----------|---------------|----------------|
| **IndexedDB Helper** | 1-204 | All new - cache management functions |
| **IPopoverProps** | 222-228 | Added `allDocuments` prop |
| **Popover** | 231-439 | Pagination UI, buttons, handlers |
| **ZoningTriggerComponent** | 1076-1274 | Pagination state, prefetch, postMessage |
| **AgentStateProvider** | 1952-2266 | Cache check, fetch all docs, cleanup |
| **Parent** | - | Optional message listener only |

---

## Files Modified
- `/Users/sethuraman/Documents/Development/POCs/react-zoning-stuff/src/stuff.tsx`

---

## Testing Checklist
- [ ] Prev button works and is disabled on first document
- [ ] Next button works and is disabled on last document
- [ ] Document indicator shows correct position
- [ ] Background prefetch doesn't block UI
- [ ] Navigation is instant when document is cached
- [ ] Blob URLs are properly cleaned up on unmount
- [ ] Works with 30-70 documents
- [ ] **IndexedDB: Cache hit works on page reload**
- [ ] **IndexedDB: Cache miss fetches from API**
- [ ] **IndexedDB: Expired entries are cleared**
- [ ] **IndexedDB: Can inspect in DevTools**
- [ ] **IndexedDB: Task change clears old cache automatically**
- [ ] **postMessage: Parent receives zoningPageChange events**
